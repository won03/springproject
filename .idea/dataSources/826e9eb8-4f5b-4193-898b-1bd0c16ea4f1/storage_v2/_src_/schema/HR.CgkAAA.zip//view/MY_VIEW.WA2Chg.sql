create view MY_VIEW as
select
    a.a_idx,
    b.b_idx,
    a.name,
    b.addr
from a, b
where a.b_idx = b.b_idx
/

