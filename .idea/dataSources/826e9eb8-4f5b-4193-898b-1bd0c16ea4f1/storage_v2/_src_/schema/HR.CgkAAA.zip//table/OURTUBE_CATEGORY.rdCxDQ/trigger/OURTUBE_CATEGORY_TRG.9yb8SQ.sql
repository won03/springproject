create trigger OURTUBE_CATEGORY_TRG
  before insert
  on OURTUBE_CATEGORY
  for each row
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

