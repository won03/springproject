create view COMMENT_VIEW as
SELECT a.acct_id,c.card_id,a.acct_userid,a.acct_name,c.comment_id,c.comment_msg,c.created_date
    
FROM comments c, accounts a
where c.acct_id = a.acct_id
/

