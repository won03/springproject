create TYPE       "ftp-log36_T" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","ftp-log-entry" "ftp-log-entry37_COLL")FINAL INSTANTIABLE
/

