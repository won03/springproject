create view USER_DIM_HIERARCHIES as
select u.name, o.name, h.hiername
from sys.hier$ h, sys.obj$ o, sys.user$ u
where h.dimobj# = o.obj#
  and o.owner# = u.user#
  and o.owner# = userenv('SCHEMAID')
/

comment on table USER_DIM_HIERARCHIES is 'Representation of a dimension hierarchy'
/

comment on column USER_DIM_HIERARCHIES.OWNER is 'Owner of the dimension'
/

comment on column USER_DIM_HIERARCHIES.DIMENSION_NAME is 'Name of the dimension'
/

comment on column USER_DIM_HIERARCHIES.HIERARCHY_NAME is 'Name of the hierarchy'
/

