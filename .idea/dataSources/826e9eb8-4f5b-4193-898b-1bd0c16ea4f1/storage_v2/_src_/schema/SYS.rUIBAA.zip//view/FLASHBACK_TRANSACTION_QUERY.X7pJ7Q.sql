create view FLASHBACK_TRANSACTION_QUERY as
select xid, start_scn, start_timestamp,
          decode(commit_scn, 0, commit_scn, 281474976710655, NULL, commit_scn)
          commit_scn, commit_timestamp,
          logon_user, undo_change#, operation, table_name, table_owner,
          row_id, undo_sql
from sys.x$ktuqqry
/

comment on table FLASHBACK_TRANSACTION_QUERY is 'Description of the flashback transaction query view'
/

comment on column FLASHBACK_TRANSACTION_QUERY.XID is 'Transaction identifier'
/

comment on column FLASHBACK_TRANSACTION_QUERY.START_SCN is 'Transaction start SCN'
/

comment on column FLASHBACK_TRANSACTION_QUERY.START_TIMESTAMP is 'Transaction start timestamp'
/

comment on column FLASHBACK_TRANSACTION_QUERY.COMMIT_SCN is 'Transaction commit SCN'
/

comment on column FLASHBACK_TRANSACTION_QUERY.COMMIT_TIMESTAMP is 'Transaction commit timestamp'
/

comment on column FLASHBACK_TRANSACTION_QUERY.LOGON_USER is 'Logon user for transaction'
/

comment on column FLASHBACK_TRANSACTION_QUERY.UNDO_CHANGE# is '1-based undo change number'
/

comment on column FLASHBACK_TRANSACTION_QUERY.OPERATION is 'forward operation for this undo'
/

comment on column FLASHBACK_TRANSACTION_QUERY.TABLE_NAME is 'table name to which this undo applies'
/

comment on column FLASHBACK_TRANSACTION_QUERY.TABLE_OWNER is 'owner of table to which this undo applies'
/

comment on column FLASHBACK_TRANSACTION_QUERY.ROW_ID is 'rowid to which this undo applies'
/

comment on column FLASHBACK_TRANSACTION_QUERY.UNDO_SQL is 'SQL corresponding to this undo'
/

