create view GV_$LOADPSTAT as
select "INST_ID","OWNER","TABNAME","PARTNAME","LOADED" from gv$loadpstat
/

