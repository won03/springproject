create view USER_CONS_OBJ_COLUMNS as
  select oc.name, c.name, ut.name, ot.name,
       lpad(decode(bitand(sc.flags, 2), 2, 'Y', 'N'), 15)
from sys."_CURRENT_EDITION_OBJ" oc, sys.col$ c, sys."_BASE_USER" ut, sys.obj$ ot,
     sys.subcoltype$ sc
where oc.owner# = userenv('SCHEMAID')
  and bitand(sc.flags, 1) = 1      /* Type is specified in the IS OF clause */
  and oc.obj#=sc.obj#
  and oc.obj#=c.obj#
  and c.intcol#=sc.intcol#
  and sc.toid=ot.oid$
  and ot.owner#=ut.user#
  and bitand(c.property,32768) != 32768                /* not unused column */
  and not exists (select null                  /* Doesn't exist in attrcol$ */
                  from sys.attrcol$ ac
                  where ac.intcol#=sc.intcol#
                        and ac.obj#=sc.obj#)
union all
select oc.name, ac.name, ut.name, ot.name,
       lpad(decode(bitand(sc.flags, 2), 2, 'Y', 'N'), 15)
from sys."_CURRENT_EDITION_OBJ" oc, sys.col$ c, sys."_BASE_USER" ut, sys.obj$ ot,
     sys.subcoltype$ sc, sys.attrcol$ ac
where oc.owner# = userenv('SCHEMAID')
  and bitand(sc.flags, 1) = 1      /* Type is specified in the IS OF clause */
  and oc.obj#=sc.obj#
  and oc.obj#=c.obj#
  and oc.obj#=ac.obj#
  and c.intcol#=sc.intcol#
  and ac.intcol#=sc.intcol#
  and sc.toid=ot.oid$
  and ot.owner#=ut.user#
  and bitand(c.property,32768) != 32768                /* not unused column */
/

comment on table USER_CONS_OBJ_COLUMNS is 'List of types an object column or attribute is constrained to in the tables owned by the user'
/

comment on column USER_CONS_OBJ_COLUMNS.TABLE_NAME is 'Name of the table containing the object column or attribute'
/

comment on column USER_CONS_OBJ_COLUMNS.COLUMN_NAME is 'Fully qualified name of the object column or attribute'
/

comment on column USER_CONS_OBJ_COLUMNS.CONS_TYPE_OWNER is 'Owner of the type that the column is constrained to'
/

comment on column USER_CONS_OBJ_COLUMNS.CONS_TYPE_NAME is 'Name of the type that the column is constrained to'
/

comment on column USER_CONS_OBJ_COLUMNS.CONS_TYPE_ONLY is 'Indication of whether the column is constrained to ONLY type'
/

