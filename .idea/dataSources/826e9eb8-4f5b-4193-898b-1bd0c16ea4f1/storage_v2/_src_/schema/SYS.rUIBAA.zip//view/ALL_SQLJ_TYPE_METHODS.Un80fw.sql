create view ALL_SQLJ_TYPE_METHODS as
select u.name, o.name, m.name, m.externVarName, m.method#,
       decode(bitand(m.properties, 512), 512, 'MAP',
              decode(bitand(m.properties, 2048), 2048, 'ORDER', 'PUBLIC')),
       m.parameters#, m.results,
       decode(bitand(m.properties, 8), 8, 'NO', 'YES'),
       decode(bitand(m.properties, 65536), 65536, 'NO', 'YES'),
       decode(bitand(m.properties, 131072), 131072, 'YES', 'NO'),
       decode(bitand(nvl(m.xflags,0), 1), 1, 'YES', 'NO')
from sys.user$ u, sys."_CURRENT_EDITION_OBJ" o, sys.type$ t, sys.method$ m
where o.owner# = u.user#
  and o.oid$ = m.toid
  and o.subname IS NULL -- get the latest version only
  and o.type# <> 10 -- must not be invalid
  and bitand(t.properties, 2048) = 0 -- not system-generated
  and t.toid = m.toid
  and t.version# = m.version#
  and t.externtype < 5
  and (o.owner# = userenv('SCHEMAID')
       or
       o.obj# in (select oa.obj#
                  from sys.objauth$ oa
                  where grantee# in (select kzsrorol
                                     from x$kzsro))
       or /* user has system privileges */
       exists (select null from v$enabledprivs
               where priv_number in (-184 /* EXECUTE ANY TYPE */,
                                     -181 /* CREATE ANY TYPE */)))
/

comment on table ALL_SQLJ_TYPE_METHODS is 'Description of methods of types accessible to the user'
/

comment on column ALL_SQLJ_TYPE_METHODS.OWNER is 'Owner of the type'
/

comment on column ALL_SQLJ_TYPE_METHODS.TYPE_NAME is 'Name of the type'
/

comment on column ALL_SQLJ_TYPE_METHODS.METHOD_NAME is 'Name of the method'
/

comment on column ALL_SQLJ_TYPE_METHODS.EXTERNAL_VAR_NAME is 'Name of the external variable'
/

comment on column ALL_SQLJ_TYPE_METHODS.METHOD_NO is 'Method number for distinguishing overloaded method (not to be used as ID number)'
/

comment on column ALL_SQLJ_TYPE_METHODS.METHOD_TYPE is 'Type of the method'
/

comment on column ALL_SQLJ_TYPE_METHODS.PARAMETERS is 'Number of parameters to the method'
/

comment on column ALL_SQLJ_TYPE_METHODS.RESULTS is 'Number of results returned by the method'
/

comment on column ALL_SQLJ_TYPE_METHODS.FINAL is 'Is the method final ?'
/

comment on column ALL_SQLJ_TYPE_METHODS.INSTANTIABLE is 'Is the method instantiable ?'
/

comment on column ALL_SQLJ_TYPE_METHODS.OVERRIDING is 'Is the method overriding a supertype method ?'
/

comment on column ALL_SQLJ_TYPE_METHODS.INHERITED is 'Is the method inherited from the supertype ?'
/

