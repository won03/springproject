create view USER_TYPES as
select o.name, t.toid,
       decode(t.typecode, 108, 'OBJECT',
                          122, 'COLLECTION',
                          o.name),
       t.attributes, t.methods,
       decode(bitand(t.properties, 16), 16, 'YES', 0, 'NO'),
       decode(bitand(t.properties, 256), 256, 'YES', 0, 'NO'),
       decode(bitand(t.properties, 8), 8, 'NO', 'YES'),
       decode(bitand(t.properties, 65536), 65536, 'NO', 'YES'),
       su.name, so.name, t.local_attrs, t.local_methods, t.typeid
from sys.type$ t, sys."_CURRENT_EDITION_OBJ" o, sys."_CURRENT_EDITION_OBJ" so,
     sys.user$ su
where o.owner# = userenv('SCHEMAID')
  and o.oid$ = t.tvoid
  and o.subname IS NULL -- only the most recent version
  and o.type# <> 10 -- must not be invalid
  and bitand(t.properties, 2048) = 0 -- not system-generated
  and t.supertoid = so.oid$ (+) and so.owner# = su.user# (+)
/

comment on table USER_TYPES is 'Description of the user''s own types'
/

comment on column USER_TYPES.TYPE_NAME is 'Name of the type'
/

comment on column USER_TYPES.TYPE_OID is 'Object identifier (OID) of the type'
/

comment on column USER_TYPES.TYPECODE is 'Typecode of the type'
/

comment on column USER_TYPES.ATTRIBUTES is 'Number of attributes (if any) in the type'
/

comment on column USER_TYPES.METHODS is 'Number of methods (if any) in the type'
/

comment on column USER_TYPES.PREDEFINED is 'Is the type a predefined type?'
/

comment on column USER_TYPES.INCOMPLETE is 'Is the type an incomplete type?'
/

comment on column USER_TYPES.FINAL is 'Is the type a final type?'
/

comment on column USER_TYPES.INSTANTIABLE is 'Is the type an instantiable type?'
/

comment on column USER_TYPES.SUPERTYPE_OWNER is 'Owner of the supertype (null if type is not a subtype)'
/

comment on column USER_TYPES.SUPERTYPE_NAME is 'Name of the supertype (null if type is not a subtype)'
/

comment on column USER_TYPES.LOCAL_ATTRIBUTES is 'Number of local (not inherited) attributes (if any) in the subtype'
/

comment on column USER_TYPES.LOCAL_METHODS is 'Number of local (not inherited) methods (if any) in the subtype'
/

comment on column USER_TYPES.TYPEID is 'Type id value of the type'
/

