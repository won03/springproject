create view V_$NLS_PARAMETERS as
select "PARAMETER","VALUE" from v$nls_parameters
/

