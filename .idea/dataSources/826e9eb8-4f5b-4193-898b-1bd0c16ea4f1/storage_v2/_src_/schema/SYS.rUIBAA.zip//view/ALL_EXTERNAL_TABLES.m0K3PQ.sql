create view ALL_EXTERNAL_TABLES as
select u.name, o.name, 'SYS', xt.type$, 'SYS', xt.default_dir,
       decode(xt.reject_limit, 2147483647, 'UNLIMITED', xt.reject_limit),
       decode(xt.par_type, 1, 'BLOB', 2, 'CLOB',       'UNKNOWN'),
       case when xt.par_type = 2 then xt.param_clob else NULL end,
       decode(xt.property, 2, 'REFERENCED', 1, 'ALL',     'UNKNOWN')
from sys.external_tab$ xt, sys.obj$ o, sys.user$ u
where o.owner# = u.user#
  and o.obj#   = xt.obj#
  and ( o.owner# = userenv('SCHEMAID')
        or o.obj# in
            ( select oa.obj# from sys.objauth$ oa
              where grantee# in (select kzsrorol from x$kzsro)
            )
        or    /* user has system privileges */
          exists ( select null from v$enabledprivs
                   where priv_number in (-45 /* LOCK ANY TABLE */,
                                         -47 /* SELECT ANY TABLE */)
                 )
      )
/

comment on table ALL_EXTERNAL_TABLES is 'Description of the external tables accessible to the user'
/

comment on column ALL_EXTERNAL_TABLES.OWNER is 'Owner of the external table'
/

comment on column ALL_EXTERNAL_TABLES.TABLE_NAME is 'Name of the external table'
/

comment on column ALL_EXTERNAL_TABLES.TYPE_OWNER is 'Owner of the implementation type for the external table access driver'
/

comment on column ALL_EXTERNAL_TABLES.TYPE_NAME is 'Name of the implementation type for the external table access driver'
/

comment on column ALL_EXTERNAL_TABLES.DEFAULT_DIRECTORY_OWNER is 'Owner of the default directory for the external table'
/

comment on column ALL_EXTERNAL_TABLES.DEFAULT_DIRECTORY_NAME is 'Name of the default directory for the external table'
/

comment on column ALL_EXTERNAL_TABLES.REJECT_LIMIT is 'Reject limit for the external table'
/

comment on column ALL_EXTERNAL_TABLES.ACCESS_TYPE is 'Type of access parameters for the external table (CLOB/BLOB)'
/

comment on column ALL_EXTERNAL_TABLES.ACCESS_PARAMETERS is 'Access parameters for the external table'
/

comment on column ALL_EXTERNAL_TABLES.PROPERTY is 'Property of the external table'
/

