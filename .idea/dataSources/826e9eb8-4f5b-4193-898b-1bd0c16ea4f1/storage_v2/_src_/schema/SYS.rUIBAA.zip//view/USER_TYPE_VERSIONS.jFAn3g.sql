create view USER_TYPE_VERSIONS as
select o.name, t.version#,
       decode(t.typecode, 108, 'OBJECT',
                          122, 'COLLECTION',
                          o.name),
       decode(o.status, 0, 'N/A', 1, 'VALID', 'INVALID'),
       s.line, s.source,
       t.hashcode
from sys."_CURRENT_EDITION_OBJ" o, sys.source$ s, sys.type$ t
  where o.obj# = s.obj# and o.oid$ = t.tvoid and o.type# = 13
  and o.owner# = userenv('SCHEMAID')
/

comment on table USER_TYPE_VERSIONS is 'Description of each version of the user''s types'
/

comment on column USER_TYPE_VERSIONS.TYPE_NAME is 'Name of the type'
/

comment on column USER_TYPE_VERSIONS.VERSION# is 'Internal version number of the type'
/

comment on column USER_TYPE_VERSIONS.TYPECODE is 'Typecode of the type'
/

comment on column USER_TYPE_VERSIONS.STATUS is 'Status of the type'
/

comment on column USER_TYPE_VERSIONS.LINE is 'Line number of the type''s spec'
/

comment on column USER_TYPE_VERSIONS.TEXT is 'Text of the type''s spec'
/

comment on column USER_TYPE_VERSIONS.HASHCODE is 'Hashcode of the type'
/

