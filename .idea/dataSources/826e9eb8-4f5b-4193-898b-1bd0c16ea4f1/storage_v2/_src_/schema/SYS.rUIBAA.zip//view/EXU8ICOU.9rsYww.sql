create view EXU8ICOU as
SELECT  "TOBJID","TOWNER","TOWNERID","TNAME","NAME","BTNAME","COLID","COLNUM","PROPERTY","BOBJID","FUNCTION","FUNCLEN"
        FROM    sys.exu8ico
        WHERE   townerid = UID
/

