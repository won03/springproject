create view ALL_IND_COLUMNS as
select io.name, idx.name, bo.name, base.name,
       decode(bitand(c.property, 1024), 1024,
              (select decode(bitand(tc.property, 1), 1, ac.name, tc.name)
              from sys.col$ tc, attrcol$ ac
              where tc.intcol# = c.intcol#-1
                and tc.obj# = c.obj#
                and tc.obj# = ac.obj#(+)
                and tc.intcol# = ac.intcol#(+)),
              decode(ac.name, null, c.name, ac.name)),
       ic.pos#, c.length, c.spare3,
       decode(bitand(c.property, 131072), 131072, 'DESC', 'ASC')
from sys.col$ c, sys.obj$ idx, sys.obj$ base, sys.icol$ ic,
     sys.user$ io, sys.user$ bo, sys.ind$ i, sys.attrcol$ ac
where ic.bo# = c.obj#
  and decode(bitand(i.property,1024),0,ic.intcol#,ic.spare2) = c.intcol#
  and ic.bo# = base.obj#
  and io.user# = idx.owner#
  and bo.user# = base.owner#
  and ic.obj# = idx.obj#
  and idx.obj# = i.obj#
  and i.type# in (1, 2, 3, 4, 6, 7, 9)
  and c.obj# = ac.obj#(+)
  and c.intcol# = ac.intcol#(+)
  and (idx.owner# = userenv('SCHEMAID') or
       base.owner# = userenv('SCHEMAID')
       or
       base.obj# in ( select obj#
                     from sys.objauth$
                     where grantee# in ( select kzsrorol
                                         from x$kzsro
                                       )
                   )
        or
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
       )
/

comment on table ALL_IND_COLUMNS is 'COLUMNs comprising INDEXes on accessible TABLES'
/

comment on column ALL_IND_COLUMNS.INDEX_OWNER is 'Index owner'
/

comment on column ALL_IND_COLUMNS.INDEX_NAME is 'Index name'
/

comment on column ALL_IND_COLUMNS.TABLE_OWNER is 'Table or cluster owner'
/

comment on column ALL_IND_COLUMNS.TABLE_NAME is 'Table or cluster name'
/

comment on column ALL_IND_COLUMNS.COLUMN_NAME is 'Column name or attribute of object column'
/

comment on column ALL_IND_COLUMNS.COLUMN_POSITION is 'Position of column or attribute within index'
/

comment on column ALL_IND_COLUMNS.COLUMN_LENGTH is 'Maximum length of the column or attribute, in bytes'
/

comment on column ALL_IND_COLUMNS.CHAR_LENGTH is 'Maximum length of the column or attribute, in characters'
/

comment on column ALL_IND_COLUMNS.DESCEND is 'DESC if this column is sorted in descending order on disk, otherwise ASC'
/

