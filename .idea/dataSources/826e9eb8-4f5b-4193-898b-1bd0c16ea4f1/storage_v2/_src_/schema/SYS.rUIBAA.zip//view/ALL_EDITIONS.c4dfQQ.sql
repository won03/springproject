create view ALL_EDITIONS as
select o.name, po.name, decode(bitand(e.flags,1),1,'NO','YES')
from sys.obj$ o, sys.edition$ e, sys.obj$ po
where o.obj# = e.obj#
  and po.obj# (+)= e.p_obj#
/

comment on table ALL_EDITIONS is 'Describes all editions in the database'
/

comment on column ALL_EDITIONS.EDITION_NAME is 'Name of the edition'
/

comment on column ALL_EDITIONS.PARENT_EDITION_NAME is 'Name of the parent edition for this edition'
/

comment on column ALL_EDITIONS.USABLE is 'A value of ''YES'' means edition is usable and ''NO'' means unusable'
/

