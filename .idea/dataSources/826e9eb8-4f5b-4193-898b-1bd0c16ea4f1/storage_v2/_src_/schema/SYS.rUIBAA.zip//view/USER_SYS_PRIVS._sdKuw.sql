create view USER_SYS_PRIVS as
select decode(sa.grantee#,1,'PUBLIC',su.name),spm.name,
       decode(min(option$),1,'YES','NO')
from  sys.system_privilege_map spm, sys.sysauth$ sa, sys.user$ su
where ((sa.grantee#=userenv('SCHEMAID') and su.user#=sa.grantee#)
       or sa.grantee#=1)
  and sa.privilege#=spm.privilege
group by decode(sa.grantee#,1,'PUBLIC',su.name),spm.name
/

comment on table USER_SYS_PRIVS is 'System privileges granted to current user'
/

comment on column USER_SYS_PRIVS.USERNAME is 'User Name or PUBLIC'
/

comment on column USER_SYS_PRIVS.PRIVILEGE is 'System privilege'
/

comment on column USER_SYS_PRIVS.ADMIN_OPTION is 'Grant was with the ADMIN option'
/

