create view EXU8SYNU as
SELECT  "SYNNAM","SYNNAM2","SYNTAB","TABOWN","TABNODE","PUBLIC$","SYNOWN","SYNOWNID","SYNTIME"
        FROM    sys.exu8syn
        WHERE   synownid = UID
/

