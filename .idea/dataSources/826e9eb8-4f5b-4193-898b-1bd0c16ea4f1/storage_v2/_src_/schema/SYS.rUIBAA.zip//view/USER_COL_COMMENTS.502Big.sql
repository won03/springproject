create view USER_COL_COMMENTS as
select o.name, c.name, co.comment$
from sys."_CURRENT_EDITION_OBJ" o, sys.col$ c, sys.com$ co
where o.owner# = userenv('SCHEMAID')
  and o.type# in (2, 4)
  and o.obj# = c.obj#
  and c.obj# = co.obj#(+)
  and c.intcol# = co.col#(+)
  and bitand(c.property, 32) = 0 /* not hidden column */
/

comment on table USER_COL_COMMENTS is 'Comments on columns of user''s tables and views'
/

comment on column USER_COL_COMMENTS.TABLE_NAME is 'Object name'
/

comment on column USER_COL_COMMENTS.COLUMN_NAME is 'Column name'
/

comment on column USER_COL_COMMENTS.COMMENTS is 'Comment on the column'
/

