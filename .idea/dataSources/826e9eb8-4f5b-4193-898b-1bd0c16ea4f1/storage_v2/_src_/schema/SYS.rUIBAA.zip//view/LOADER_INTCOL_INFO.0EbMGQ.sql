create view LOADER_INTCOL_INFO as
select o.name as table_name, c.name as col_name, c.intcol# as intcol
          from sys.col$ c, sys.obj$ o, sys.user$ u where
            o.obj# = c.obj# and u.user# = o.owner#
            and (o.owner# = userenv('schemaid')
                  or o.obj# in
                       (select oa.obj#
                        from sys.objauth$ oa
                        where grantee# in ( select kzsrorol
                                            from x$kzsro
                                          )
                       )
                  or /* user has system privileges */
                     exists (select null from v$enabledprivs
                             where priv_number in (-45 /* LOCK   ANY TABLE */,
                                                   -47 /* SELECT ANY TABLE */,
                                                   -48 /* INSERT ANY TABLE */,
                                                   -49 /* UPDATE ANY TABLE */,
                                                   -50 /* DELETE ANY TABLE */)
                             )
                 )
/

