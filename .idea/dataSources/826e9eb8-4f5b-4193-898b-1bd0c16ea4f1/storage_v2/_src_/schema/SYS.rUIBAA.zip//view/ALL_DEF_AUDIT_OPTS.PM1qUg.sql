create view ALL_DEF_AUDIT_OPTS as
select substr(t.audit$, 1, 1) || '/' || substr(t.audit$, 2, 1),
       substr(t.audit$, 3, 1) || '/' || substr(t.audit$, 4, 1),
       substr(t.audit$, 5, 1) || '/' || substr(t.audit$, 6, 1),
       substr(t.audit$, 7, 1) || '/' || substr(t.audit$, 8, 1),
       substr(t.audit$, 9, 1) || '/' || substr(t.audit$, 10, 1),
       substr(t.audit$, 11, 1) || '/' || substr(t.audit$, 12, 1),
       substr(t.audit$, 13, 1) || '/' || substr(t.audit$, 14, 1),
       substr(t.audit$, 15, 1) || '/' || substr(t.audit$, 16, 1),
       substr(t.audit$, 17, 1) || '/' || substr(t.audit$, 18, 1),
       substr(t.audit$, 19, 1) || '/' || substr(t.audit$, 20, 1),
       substr(t.audit$, 21, 1) || '/' || substr(t.audit$, 22, 1),
       '-/-',                                            /* dummy REF column */
       substr(t.audit$, 25, 1) || '/' || substr(t.audit$, 26, 1),
       substr(t.audit$, 23, 1) || '/' || substr(t.audit$, 24, 1),
       substr(t.audit$, 29, 1) || '/' || substr(t.audit$, 30, 1)
from sys.obj$ o, sys.tab$ t
where o.obj# = t.obj#
  and o.owner# = 0
  and o.name = '_default_auditing_options_'
/

comment on table ALL_DEF_AUDIT_OPTS is 'Auditing options for newly created objects'
/

comment on column ALL_DEF_AUDIT_OPTS.ALT is 'Auditing ALTER WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/

comment on column ALL_DEF_AUDIT_OPTS.AUD is 'Auditing AUDIT WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/

comment on column ALL_DEF_AUDIT_OPTS.COM is 'Auditing COMMENT WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/

comment on column ALL_DEF_AUDIT_OPTS.DEL is 'Auditing DELETE WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/

comment on column ALL_DEF_AUDIT_OPTS.GRA is 'Auditing GRANT WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/

comment on column ALL_DEF_AUDIT_OPTS.IND is 'Auditing INDEX WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/

comment on column ALL_DEF_AUDIT_OPTS.INS is 'Auditing INSERT WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/

comment on column ALL_DEF_AUDIT_OPTS.LOC is 'Auditing LOCK WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/

comment on column ALL_DEF_AUDIT_OPTS.REN is 'Auditing RENAME WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/

comment on column ALL_DEF_AUDIT_OPTS.SEL is 'Auditing SELECT WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/

comment on column ALL_DEF_AUDIT_OPTS.UPD is 'Auditing UPDATE WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/

comment on column ALL_DEF_AUDIT_OPTS.REF is 'Dummy REF column. Maintained for backward compatibility of the view'
/

comment on column ALL_DEF_AUDIT_OPTS.EXE is 'Auditing EXECUTE WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/

comment on column ALL_DEF_AUDIT_OPTS.FBK is 'Auditing FLASHBACK WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/

comment on column ALL_DEF_AUDIT_OPTS.REA is 'Auditing READ WHENEVER SUCCESSFUL / UNSUCCESSFUL'
/

