create view USER_DIM_JOIN_KEY as
select d."OWNER",d."DIMENSION_NAME",d."DIM_KEY_ID",d."LEVEL_NAME",d."KEY_POSITION",d."HIERARCHY_NAME",d."CHILD_JOIN_OWNER",d."CHILD_JOIN_TABLE",d."CHILD_JOIN_COLUMN",d."CHILD_LEVEL_NAME" FROM dba_dim_join_key d, sys.user$ u
where u.user# = userenv('SCHEMAID')
  and d.owner = u.name
/

comment on table USER_DIM_JOIN_KEY is 'Representation of a join between two dimension tables. '
/

comment on column USER_DIM_JOIN_KEY.OWNER is 'Owner of the dimension'
/

comment on column USER_DIM_JOIN_KEY.DIMENSION_NAME is 'Name of the dimension'
/

comment on column USER_DIM_JOIN_KEY.DIM_KEY_ID is 'Join key ID (unique within a dimension)'
/

comment on column USER_DIM_JOIN_KEY.LEVEL_NAME is 'Name of the hierarchy level'
/

comment on column USER_DIM_JOIN_KEY.KEY_POSITION is 'Position of the key column within the level'
/

comment on column USER_DIM_JOIN_KEY.HIERARCHY_NAME is 'Name of the hierarchy'
/

comment on column USER_DIM_JOIN_KEY.CHILD_JOIN_OWNER is 'Owner of the join column table'
/

comment on column USER_DIM_JOIN_KEY.CHILD_JOIN_TABLE is 'Name of the join column table'
/

comment on column USER_DIM_JOIN_KEY.CHILD_JOIN_COLUMN is 'Name of the join column'
/

comment on column USER_DIM_JOIN_KEY.CHILD_LEVEL_NAME is 'Name of the child hierarchy level of the join key'
/

