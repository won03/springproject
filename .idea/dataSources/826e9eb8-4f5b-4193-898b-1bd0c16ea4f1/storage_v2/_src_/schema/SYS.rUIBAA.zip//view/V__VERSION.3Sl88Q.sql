create view V_$VERSION as
select "BANNER" from v$version
/

