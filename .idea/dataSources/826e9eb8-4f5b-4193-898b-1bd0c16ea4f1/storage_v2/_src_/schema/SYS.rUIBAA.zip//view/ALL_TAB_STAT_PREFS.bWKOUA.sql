create view ALL_TAB_STAT_PREFS as
select u.name, o.name, p.pname, p.valchar
from  sys.optstat_user_prefs$ p, obj$ o, user$ u
where p.obj#=o.obj#
  and u.user#=o.owner#
  and o.type#=2
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
                 )
        )
/

comment on table ALL_TAB_STAT_PREFS is 'Statistics preferences for tables'
/

comment on column ALL_TAB_STAT_PREFS.OWNER is 'Name of the owner'
/

comment on column ALL_TAB_STAT_PREFS.TABLE_NAME is 'Name of the table'
/

comment on column ALL_TAB_STAT_PREFS.PREFERENCE_NAME is 'Preference name'
/

comment on column ALL_TAB_STAT_PREFS.PREFERENCE_VALUE is 'Preference value'
/

