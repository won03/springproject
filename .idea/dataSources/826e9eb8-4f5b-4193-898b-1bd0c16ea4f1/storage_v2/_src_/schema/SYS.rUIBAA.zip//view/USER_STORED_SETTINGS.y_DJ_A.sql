create view USER_STORED_SETTINGS as
SELECT o.name, o.obj#,
DECODE(o.type#,
        7, 'PROCEDURE',
        8, 'FUNCTION',
        9, 'PACKAGE',
       11, 'PACKAGE BODY',
       12, 'TRIGGER',
       13, 'TYPE',
       14, 'TYPE BODY',
       'UNDEFINED'),
p.param, p.value
FROM sys."_CURRENT_EDITION_OBJ" o, sys.settings$ p
WHERE o.linkname is null
AND p.obj# = o.obj#
AND o.owner# = userenv('SCHEMAID')
AND (o.type# in (7, 8, 9, 11, 12, 14) or (o.type# = 13 and o.subname is null))
/

comment on table USER_STORED_SETTINGS is 'Parameter settings for objects owned by the user'
/

comment on column USER_STORED_SETTINGS.OBJECT_NAME is 'Name of the object'
/

comment on column USER_STORED_SETTINGS.OBJECT_ID is 'Object number of the object'
/

comment on column USER_STORED_SETTINGS.OBJECT_TYPE is 'Type of the object'
/

comment on column USER_STORED_SETTINGS.PARAM_NAME is 'Name of the parameter'
/

comment on column USER_STORED_SETTINGS.PARAM_VALUE is 'Value of the parameter'
/

