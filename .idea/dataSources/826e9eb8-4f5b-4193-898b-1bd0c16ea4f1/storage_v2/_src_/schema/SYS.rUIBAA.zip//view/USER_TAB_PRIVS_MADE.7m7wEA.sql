create view USER_TAB_PRIVS_MADE as
select ue.name, o.name, ur.name, tpm.name,
       decode(mod(oa.option$,2), 1, 'YES', 'NO'),
       decode(bitand(oa.option$,2), 2, 'YES', 'NO')
from sys.objauth$ oa, sys."_CURRENT_EDITION_OBJ" o, sys.user$ ue, sys.user$ ur,
     table_privilege_map tpm
where oa.obj# = o.obj#
  and oa.grantor# = ur.user#
  and oa.grantee# = ue.user#
  and oa.col# is null
  and oa.privilege# = tpm.privilege
  and o.owner# = userenv('SCHEMAID')
/

comment on table USER_TAB_PRIVS_MADE is 'All grants on objects owned by the user'
/

comment on column USER_TAB_PRIVS_MADE.GRANTEE is 'Name of the user to whom access was granted'
/

comment on column USER_TAB_PRIVS_MADE.TABLE_NAME is 'Name of the object'
/

comment on column USER_TAB_PRIVS_MADE.GRANTOR is 'Name of the user who performed the grant'
/

comment on column USER_TAB_PRIVS_MADE.PRIVILEGE is 'Table Privilege'
/

comment on column USER_TAB_PRIVS_MADE.GRANTABLE is 'Privilege is grantable'
/

comment on column USER_TAB_PRIVS_MADE.HIERARCHY is 'Privilege is with hierarchy option'
/

