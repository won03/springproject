create view ALL_DIM_CHILD_OF as
select d."OWNER",d."DIMENSION_NAME",d."HIERARCHY_NAME",d."POSITION",d."CHILD_LEVEL_NAME",d."JOIN_KEY_ID",d."PARENT_LEVEL_NAME" from dba_dim_child_of d, sys.obj$ o, sys.user$ u
where o.owner#         = u.user#
  and d.dimension_name = o.name
  and d.owner          = u.name
  and o.type#          = 43                     /* dimension */
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-215 /* CREATE ANY DIMENSION */,
                                       -216 /* ALTER ANY DIMENSION */,
                                       -217 /* DROP ANY DIMENSION */)
                 )
      )
/

comment on table ALL_DIM_CHILD_OF is 'Representaion of a 1:n hierarchical relationship between a pair of levels in
 a dimension'
/

comment on column ALL_DIM_CHILD_OF.OWNER is 'Owner of the dimension'
/

comment on column ALL_DIM_CHILD_OF.DIMENSION_NAME is 'Name of the dimension'
/

comment on column ALL_DIM_CHILD_OF.HIERARCHY_NAME is 'Name of the hierarchy'
/

comment on column ALL_DIM_CHILD_OF.POSITION is 'Hierarchical position within this hierarchy, position 1 being
 the most detailed'
/

comment on column ALL_DIM_CHILD_OF.CHILD_LEVEL_NAME is 'Name of the child-side level of this 1:n relationship'
/

comment on column ALL_DIM_CHILD_OF.JOIN_KEY_ID is 'Keys that join child to the parent'
/

comment on column ALL_DIM_CHILD_OF.PARENT_LEVEL_NAME is 'Name of the parent-side level of this 1:n relationship'
/

