create view USER_MVIEW_DETAIL_SUBPARTITION as
select m."OWNER",m."MVIEW_NAME",m."DETAILOBJ_OWNER",m."DETAILOBJ_NAME",m."DETAIL_PARTITION_NAME",m."DETAIL_SUBPARTITION_NAME",m."DETAIL_SUBPARTITION_POSITION",m."FRESHNESS" from dba_mview_detail_subpartition m, sys.user$ u
where u.user# = userenv('SCHEMAID')
  and m.owner = u.name
/

comment on table USER_MVIEW_DETAIL_SUBPARTITION is 'Freshness information of all PCT materialized views in the database'
/

comment on column USER_MVIEW_DETAIL_SUBPARTITION.OWNER is 'Owner of the materialized view'
/

comment on column USER_MVIEW_DETAIL_SUBPARTITION.MVIEW_NAME is 'Name of the materialized view'
/

comment on column USER_MVIEW_DETAIL_SUBPARTITION.DETAILOBJ_NAME is 'Name of the detail object'
/

comment on column USER_MVIEW_DETAIL_SUBPARTITION.DETAIL_PARTITION_NAME is 'Name of the detail object partition'
/

comment on column USER_MVIEW_DETAIL_SUBPARTITION.DETAIL_SUBPARTITION_NAME is 'Name of the detail object subpartition'
/

comment on column USER_MVIEW_DETAIL_SUBPARTITION.DETAIL_SUBPARTITION_POSITION is 'Position of the detail object subpartition'
/

comment on column USER_MVIEW_DETAIL_SUBPARTITION.FRESHNESS is 'Freshness of the detail object partition'
/

