create view USER_MINING_MODEL_SETTINGS as
select o.name, s.name, s.value,
       decode(bitand(s.properties,1),1,'INPUT','DEFAULT')
from sys.modelset$ s, sys.obj$ o
where s.mod#=o.obj#
  and o.owner#=userenv('SCHEMAID')
  and bitand(s.properties,2) != 2
/

comment on table USER_MINING_MODEL_SETTINGS is 'Description of the user''s own model settings'
/

comment on column USER_MINING_MODEL_SETTINGS.MODEL_NAME is 'Name of the model to which the setting belongs'
/

comment on column USER_MINING_MODEL_SETTINGS.SETTING_NAME is 'Name of the setting'
/

comment on column USER_MINING_MODEL_SETTINGS.SETTING_VALUE is 'Value of the setting'
/

comment on column USER_MINING_MODEL_SETTINGS.SETTING_TYPE is 'Type of the setting'
/

