create view EXU81SPOKU as
SELECT  "OBJID","OWNERID","POSNO","NAME","PROPERTY","FUNCTION","FUNCLEN"
        FROM    sys.exu81spok
        WHERE   ownerid = UID
/

