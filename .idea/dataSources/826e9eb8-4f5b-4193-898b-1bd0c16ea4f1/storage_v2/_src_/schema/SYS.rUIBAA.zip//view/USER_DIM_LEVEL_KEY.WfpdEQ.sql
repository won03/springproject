create view USER_DIM_LEVEL_KEY as
select u.name, o.name, dl.levelname, dlk.keypos#, c.name
from sys.dimlevelkey$ dlk, sys.obj$ o, sys.user$ u, sys.dimlevel$ dl,
     sys.col$ c
where dlk.dimobj# = o.obj#
  and o.owner# = u.user#
  and dlk.dimobj# = dl.dimobj#
  and dlk.levelid# = dl.levelid#
  and dlk.detailobj# = c.obj#
  and dlk.col# = c.intcol#
  and o.owner# = userenv('SCHEMAID')
/

comment on table USER_DIM_LEVEL_KEY is 'Representations of columns of a dimension level'
/

comment on column USER_DIM_LEVEL_KEY.OWNER is 'Owner of the dimension'
/

comment on column USER_DIM_LEVEL_KEY.DIMENSION_NAME is 'Name of the dimension'
/

comment on column USER_DIM_LEVEL_KEY.LEVEL_NAME is 'Name of the hierarchy level'
/

comment on column USER_DIM_LEVEL_KEY.KEY_POSITION is 'Ordinal position of the key column within the level'
/

comment on column USER_DIM_LEVEL_KEY.COLUMN_NAME is 'Name of the key column'
/

