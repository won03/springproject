create view ALL_LIBRARIES as
select u.name,
       o.name,
       l.filespec,
       decode(bitand(l.property, 1), 0, 'Y', 1, 'N', NULL),
       decode(o.status, 0, 'N/A', 1, 'VALID', 'INVALID')
from sys."_CURRENT_EDITION_OBJ" o, sys.library$ l, sys.user$ u
where o.owner# = u.user#
  and o.obj# = l.obj#
  and (o.owner# in (userenv('SCHEMAID'), 1 /* PUBLIC */)
       or o.obj# in
          ( select oa.obj#
            from sys.objauth$ oa
            where grantee# in (select kzsrorol from x$kzsro)
          )
       or (
            exists (select NULL from v$enabledprivs
                    where priv_number in (
                                      -189 /* CREATE ANY LIBRARY */,
                                      -190 /* ALTER ANY LIBRARY */,
                                      -191 /* DROP ANY LIBRARY */,
                                      -192 /* EXECUTE ANY LIBRARY */
                                         )
                   )
          )
      )
/

comment on table ALL_LIBRARIES is 'Description of libraries accessible to the user'
/

comment on column ALL_LIBRARIES.OWNER is 'Owner of the library'
/

comment on column ALL_LIBRARIES.LIBRARY_NAME is 'Name of the library'
/

comment on column ALL_LIBRARIES.FILE_SPEC is 'Operating system file specification of the library'
/

comment on column ALL_LIBRARIES.DYNAMIC is 'Is the library dynamically loadable'
/

comment on column ALL_LIBRARIES.STATUS is 'Status of the library'
/

