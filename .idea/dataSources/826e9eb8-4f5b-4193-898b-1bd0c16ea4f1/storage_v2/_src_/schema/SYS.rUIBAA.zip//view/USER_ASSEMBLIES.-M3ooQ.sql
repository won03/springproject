create view USER_ASSEMBLIES as
select o.name,
       a.filespec,
       decode(a.security_level, 0, 'SAFE', 1, 'EXTERNAL_1', 2, 'EXTERNAL_2',
                                3, 'EXTERNAL_3', 4, 'UNSAFE'),
       a.identity,
       decode(o.status, 0, 'N/A', 1, 'VALID', 'INVALID')
from sys."_CURRENT_EDITION_OBJ" o, sys.assembly$ a
where o.owner# = userenv('SCHEMAID')
  and o.obj# = a.obj#
/

comment on table USER_ASSEMBLIES is 'Description of the user''s own assemblies'
/

comment on column USER_ASSEMBLIES.ASSEMBLY_NAME is 'Name of the assembly'
/

comment on column USER_ASSEMBLIES.FILE_SPEC is 'Operating system file specification of the assembly'
/

comment on column USER_ASSEMBLIES.SECURITY_LEVEL is 'The maximum security level of the assembly'
/

comment on column USER_ASSEMBLIES.IDENTITY is 'The identity of the assembly'
/

comment on column USER_ASSEMBLIES.STATUS is 'Status of the assembly'
/

