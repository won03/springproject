create view ALL_SUMMAP as
select XID, COMMIT_SCN from sys.snap_xcmt$
/

comment on table ALL_SUMMAP is 'mapping entries of transaction ID and commit SCN accessible to the user'
/

comment on column ALL_SUMMAP.XID is 'The ID of a transaction'
/

comment on column ALL_SUMMAP.COMMIT_SCN is 'The commit SCN of a transaction'
/

