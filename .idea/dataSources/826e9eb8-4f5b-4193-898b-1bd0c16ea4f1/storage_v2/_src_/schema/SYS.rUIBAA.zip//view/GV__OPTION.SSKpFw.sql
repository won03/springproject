create view GV_$OPTION as
select "INST_ID","PARAMETER","VALUE" from gv$option
/

