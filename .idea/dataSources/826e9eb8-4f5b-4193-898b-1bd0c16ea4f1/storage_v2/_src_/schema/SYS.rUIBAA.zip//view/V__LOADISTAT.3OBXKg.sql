create view V_$LOADISTAT as
select "OWNER","TABNAME","INDEXNAME","SUBNAME","MESSAGE_NUM","MESSAGE" from v$loadistat
/

