create view ALL_REWRITE_EQUIVALENCES as
select m."OWNER",m."NAME",m."SOURCE_STMT",m."DESTINATION_STMT",m."REWRITE_MODE" from dba_rewrite_equivalences m, sys.obj$ o, sys.user$ u
where o.owner# = u.user#
  and m.name   = o.name
  and u.name   = m.owner
  and ( o.owner# = userenv('SCHEMAID')
        or
        o.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                        from x$kzsro
                                      )
                  )
        or /* user has system privileges */
        exists ( select null from v$enabledprivs
                 where priv_number in (-45 /* LOCK ANY TABLE */,
                                       -47 /* SELECT ANY TABLE */,
                                       -48 /* INSERT ANY TABLE */,
                                       -49 /* UPDATE ANY TABLE */,
                                       -50 /* DELETE ANY TABLE */)
               )
      )
/

comment on table ALL_REWRITE_EQUIVALENCES is 'Description of all rewrite equivalence accessible to the user'
/

comment on column ALL_REWRITE_EQUIVALENCES.OWNER is 'Owner of the rewrite equivalence'
/

comment on column ALL_REWRITE_EQUIVALENCES.NAME is 'Name of the rewrite equivalence'
/

comment on column ALL_REWRITE_EQUIVALENCES.SOURCE_STMT is 'Source statement of the rewrite equivalence'
/

comment on column ALL_REWRITE_EQUIVALENCES.DESTINATION_STMT is 'Destination of the rewrite equivalence'
/

comment on column ALL_REWRITE_EQUIVALENCES.REWRITE_MODE is 'Rewrite mode of the rewrite equivalence'
/

