create view USER_INDEXTYPE_OPERATORS as
select u.name, o.name, u1.name, op.name, i.bind#
from sys.user$ u, sys.indop$ i, sys.obj$ o,
sys.obj$ op, sys.user$ u1
where i.obj# = o.obj# and i.oper# = op.obj# and
      u.user# = o.owner# and u1.user#=op.owner# and
      o.owner# = userenv ('SCHEMAID') and bitand(i.property, 4) != 4
/

comment on table USER_INDEXTYPE_OPERATORS is 'All user indextype operators'
/

comment on column USER_INDEXTYPE_OPERATORS.OWNER is 'Owner of the indextype'
/

comment on column USER_INDEXTYPE_OPERATORS.INDEXTYPE_NAME is 'Name of the indextype'
/

comment on column USER_INDEXTYPE_OPERATORS.OPERATOR_SCHEMA is 'Name of the operator schema'
/

comment on column USER_INDEXTYPE_OPERATORS.OPERATOR_NAME is 'Name of the operator for which the indextype is defined'
/

comment on column USER_INDEXTYPE_OPERATORS.BINDING# is 'Binding# associated with the operator'
/

