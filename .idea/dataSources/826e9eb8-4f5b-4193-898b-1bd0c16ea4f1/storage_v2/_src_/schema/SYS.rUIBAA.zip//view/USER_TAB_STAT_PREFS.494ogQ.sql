create view USER_TAB_STAT_PREFS as
select o.name, p.pname, p.valchar
from  sys.optstat_user_prefs$ p, obj$ o
where p.obj#=o.obj#
  and o.type#=2
  and o.owner# = userenv('SCHEMAID')
/

comment on table USER_TAB_STAT_PREFS is 'Statistics preferences for tables'
/

comment on column USER_TAB_STAT_PREFS.TABLE_NAME is 'Name of the table'
/

comment on column USER_TAB_STAT_PREFS.PREFERENCE_NAME is 'Preference name'
/

comment on column USER_TAB_STAT_PREFS.PREFERENCE_VALUE is 'Preference value'
/

