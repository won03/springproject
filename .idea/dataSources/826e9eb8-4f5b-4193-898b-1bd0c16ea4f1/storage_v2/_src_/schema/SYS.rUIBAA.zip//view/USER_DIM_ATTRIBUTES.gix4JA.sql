create view USER_DIM_ATTRIBUTES as
select u.name, o.name, da.attname, dl.levelname, c.name, 'N'
from sys.dimattr$ da, sys.obj$ o, sys.user$ u, sys.dimlevel$ dl, sys.col$ c
where da.dimobj# = o.obj#
  and o.owner# = u.user#
  and da.dimobj# = dl.dimobj#
  and da.levelid# = dl.levelid#
  and da.detailobj# = c.obj#
  and da.col# = c.intcol#
  and o.owner# = userenv('SCHEMAID')
/

comment on table USER_DIM_ATTRIBUTES is 'Representation of the relationship between a dimension level and
 a functionally dependent column'
/

comment on column USER_DIM_ATTRIBUTES.OWNER is 'Owner of the dimentsion'
/

comment on column USER_DIM_ATTRIBUTES.DIMENSION_NAME is 'Name of the dimension'
/

comment on column USER_DIM_ATTRIBUTES.ATTRIBUTE_NAME is 'Name of the attribute'
/

comment on column USER_DIM_ATTRIBUTES.LEVEL_NAME is 'Name of the hierarchy level'
/

comment on column USER_DIM_ATTRIBUTES.COLUMN_NAME is 'Name of the dependent column'
/

comment on column USER_DIM_ATTRIBUTES.INFERRED is 'Whether this attribute is inferred from a JOIN KEY specification'
/

