create view USER_TAB_PENDING_STATS as
  select o.name, null, null, h.rowcnt, h.blkcnt, h.avgrln,
         h.samplesize, h.analyzetime
  from   sys.obj$ o, sys.wri$_optstat_tab_history h
  where  h.obj# = o.obj# and o.type# = 2
         and o.owner# = userenv('SCHEMAID')
         and h.savtime > systimestamp
  union all
  -- partitions
  select o.name, o.subname, null, h.rowcnt, h.blkcnt,
         h.avgrln, h.samplesize, h.analyzetime
  from   sys.obj$ o, sys.wri$_optstat_tab_history h
  where  h.obj# = o.obj# and o.type# = 19
         and o.owner# = userenv('SCHEMAID')
         and h.savtime > systimestamp
  union all
  -- sub partitions
  select osp.name, ocp.subname, osp.subname, h.rowcnt,
         h.blkcnt, h.avgrln, h.samplesize, h.analyzetime
  from  sys.obj$ osp, sys.obj$ ocp,  sys.tabsubpart$ tsp,
        sys.wri$_optstat_tab_history h
  where h.obj# = osp.obj# and osp.type# = 34 and osp.obj# = tsp.obj#
        and tsp.pobj# = ocp.obj#
        and osp.owner# = userenv('SCHEMAID')
        and h.savtime > systimestamp
/

comment on table USER_TAB_PENDING_STATS is 'History of table statistics modifications'
/

comment on column USER_TAB_PENDING_STATS.TABLE_NAME is 'Name of the table'
/

comment on column USER_TAB_PENDING_STATS.PARTITION_NAME is 'Name of the partition'
/

comment on column USER_TAB_PENDING_STATS.SUBPARTITION_NAME is 'Name of the subpartition'
/

comment on column USER_TAB_PENDING_STATS.NUM_ROWS is 'Number of rows'
/

comment on column USER_TAB_PENDING_STATS.BLOCKS is 'Number of blocks'
/

comment on column USER_TAB_PENDING_STATS.AVG_ROW_LEN is 'Average row length'
/

comment on column USER_TAB_PENDING_STATS.SAMPLE_SIZE is 'Sample size'
/

comment on column USER_TAB_PENDING_STATS.LAST_ANALYZED is 'Time of last analyze'
/

