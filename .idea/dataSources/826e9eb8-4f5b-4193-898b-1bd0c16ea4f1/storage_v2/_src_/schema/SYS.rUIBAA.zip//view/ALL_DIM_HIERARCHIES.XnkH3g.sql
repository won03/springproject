create view ALL_DIM_HIERARCHIES as
select u.name, o.name, h.hiername
from sys.hier$ h, sys.obj$ o, sys.user$ u
where h.dimobj# = o.obj#
  and o.owner# = u.user#
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-215 /* CREATE ANY DIMENSION */,
                                       -216 /* ALTER ANY DIMENSION */,
                                       -217 /* DROP ANY DIMENSION */)
                 )
      )
/

comment on table ALL_DIM_HIERARCHIES is 'Representation of a dimension hierarchy'
/

comment on column ALL_DIM_HIERARCHIES.OWNER is 'Owner of the dimension'
/

comment on column ALL_DIM_HIERARCHIES.DIMENSION_NAME is 'Name of the dimension'
/

comment on column ALL_DIM_HIERARCHIES.HIERARCHY_NAME is 'Name of the hierarchy'
/

