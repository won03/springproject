create view LOADER_SKIP_UNUSABLE_INDEXES as
select count(*) as value from v$parameter
   where upper(name) = 'SKIP_UNUSABLE_INDEXES'
   and value = 'TRUE'
/

