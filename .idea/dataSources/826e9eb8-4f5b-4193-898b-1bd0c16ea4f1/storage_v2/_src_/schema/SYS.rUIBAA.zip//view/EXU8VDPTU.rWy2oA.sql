create view EXU8VDPTU as
SELECT  "PARENT","CHILD","POWNER","COWNER"
        FROM    sys.exu8vdpt
/

