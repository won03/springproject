create view USER_EXTERNAL_LOCATIONS as
select o.name, xl.name, 'SYS', nvl(xl.dir, xt.default_dir)
from sys.external_location$ xl, sys.obj$ o, sys.external_tab$ xt
where o.owner# = userenv('SCHEMAID')
  and o.obj# = xl.obj#
  and o.obj# = xt.obj#
/

comment on table USER_EXTERNAL_LOCATIONS is 'Description of the user''s external tables locations'
/

comment on column USER_EXTERNAL_LOCATIONS.TABLE_NAME is 'Name of the corresponding external table'
/

comment on column USER_EXTERNAL_LOCATIONS.LOCATION is 'External table location clause'
/

comment on column USER_EXTERNAL_LOCATIONS.DIRECTORY_OWNER is 'Owner of the directory containing the external table location'
/

comment on column USER_EXTERNAL_LOCATIONS.DIRECTORY_NAME is 'Name of the directory containing the location'
/

