create view ALL_DIM_LEVEL_KEY as
select u.name, o.name, dl.levelname, dlk.keypos#, c.name
from sys.dimlevelkey$ dlk, sys.obj$ o, sys.user$ u, sys.dimlevel$ dl,
     sys.col$ c
where dlk.dimobj# = o.obj#
  and o.owner# = u.user#
  and dlk.dimobj# = dl.dimobj#
  and dlk.levelid# = dl.levelid#
  and dlk.detailobj# = c.obj#
  and dlk.col# = c.intcol#
  and (o.owner# = userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where grantee# in ( select kzsrorol
                                 from x$kzsro
                               )
            )
       or /* user has system privileges */
         exists (select null from v$enabledprivs
                 where priv_number in (-215 /* CREATE ANY DIMENSION */,
                                       -216 /* ALTER ANY DIMENSION */,
                                       -217 /* DROP ANY DIMENSION */)
                 )
      )
/

comment on table ALL_DIM_LEVEL_KEY is 'Representations of columns of a dimension level'
/

comment on column ALL_DIM_LEVEL_KEY.OWNER is 'Owner of the dimension'
/

comment on column ALL_DIM_LEVEL_KEY.DIMENSION_NAME is 'Name of the dimension'
/

comment on column ALL_DIM_LEVEL_KEY.LEVEL_NAME is 'Name of the hierarchy level'
/

comment on column ALL_DIM_LEVEL_KEY.KEY_POSITION is 'Ordinal position of the key column within the level'
/

comment on column ALL_DIM_LEVEL_KEY.COLUMN_NAME is 'Name of the key column'
/

