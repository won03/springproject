create view USER_INDEXTYPE_COMMENTS as
select  u.name, o.name, c.comment$
from    sys.obj$ o, sys.user$ u, sys.indtypes$ i, sys.com$ c
where   o.obj# = i.obj# and u.user# = o.owner# and c.obj# = i.obj#
        and o.owner# = userenv('SCHEMAID')
/

comment on table USER_INDEXTYPE_COMMENTS is 'Comments for user-defined indextypes'
/

comment on column USER_INDEXTYPE_COMMENTS.OWNER is 'Owner of the user-defined indextype'
/

comment on column USER_INDEXTYPE_COMMENTS.INDEXTYPE_NAME is 'Name of the user-defined indextype'
/

comment on column USER_INDEXTYPE_COMMENTS.COMMENTS is 'Comment for the user-defined indextype'
/

