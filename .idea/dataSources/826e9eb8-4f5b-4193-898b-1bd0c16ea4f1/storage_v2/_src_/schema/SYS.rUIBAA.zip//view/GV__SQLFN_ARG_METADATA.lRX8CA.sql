create view GV_$SQLFN_ARG_METADATA as
select "INST_ID","FUNC_ID","ARGNUM","DATATYPE","DESCR" from gv$sqlfn_arg_metadata
/

