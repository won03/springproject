create view EXU8INKU as
SELECT  "OBJID","OWNERID","INTCOLID","NAME"
        FROM    sys.exu8ink
        WHERE   ownerid = UID
/

