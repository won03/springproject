create view EXU8ORDU as
SELECT  "DLEVEL","OBJ#","D_OWNER#"
        FROM    sys.exu8ord
        WHERE   d_owner# = UID
/

