create view USER_UPDATABLE_COLUMNS as
select u.name, o.name, c.name,
       decode(bitand(c.fixedstorage,2),
              2, decode(bitand(v.flags,8192), 8192, 'YES', 'NO'),
              decode(bitand(c.property,4096),4096,'NO','YES')),
       decode(bitand(c.fixedstorage,2),
              2, decode(bitand(v.flags,4096), 4096, 'YES', 'NO'),
              decode(bitand(c.property,2048),2048,'NO','YES')),
       decode(bitand(c.fixedstorage,2),
              2, decode(bitand(v.flags,16384), 16384, 'YES', 'NO'),
              decode(bitand(c.property,8192),8192,'NO','YES'))
from sys."_CURRENT_EDITION_OBJ" o, sys.user$ u, sys.col$ c, sys.view$ v
where u.user# = o.owner#
  and c.obj#  = o.obj#
  and c.obj#  = v.obj#(+)
  and u.user# = userenv('SCHEMAID')
  and bitand(c.property, 32) = 0 /* not hidden column */
/

comment on table USER_UPDATABLE_COLUMNS is 'Description of updatable columns'
/

comment on column USER_UPDATABLE_COLUMNS.OWNER is 'Table owner'
/

comment on column USER_UPDATABLE_COLUMNS.TABLE_NAME is 'Table name'
/

comment on column USER_UPDATABLE_COLUMNS.COLUMN_NAME is 'Column name'
/

comment on column USER_UPDATABLE_COLUMNS.UPDATABLE is 'Is the column updatable?'
/

comment on column USER_UPDATABLE_COLUMNS.INSERTABLE is 'Is the column insertable?'
/

comment on column USER_UPDATABLE_COLUMNS.DELETABLE is 'Is the column deletable?'
/

