create view ALL_MINING_MODEL_SETTINGS as
select u.name, o.name, s.name, s.value,
       decode(s.properties,1,'INPUT','DEFAULT')
from sys.modelset$ s, sys.obj$ o, sys.user$ u
where s.mod#=o.obj#
  and o.owner#=u.user#
  and (o.owner#=userenv('SCHEMAID')
       or o.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where oa.grantee# in ( select kzsrorol
                                         from x$kzsro
                                  )
            )
        or /* user has system privileges */
          exists (select null from v$enabledprivs
                  where priv_number in (-293 /* SELECT ANY MINING MODEL */)
                  )
      )
  and bitand(s.properties,2) != 2
/

comment on table ALL_MINING_MODEL_SETTINGS is 'Description of all the settings accessible to the user'
/

comment on column ALL_MINING_MODEL_SETTINGS.MODEL_NAME is 'Name of the model to which the setting belongs'
/

comment on column ALL_MINING_MODEL_SETTINGS.SETTING_NAME is 'Name of the setting'
/

comment on column ALL_MINING_MODEL_SETTINGS.SETTING_VALUE is 'Value of the setting'
/

comment on column ALL_MINING_MODEL_SETTINGS.SETTING_TYPE is 'Type of the setting'
/

