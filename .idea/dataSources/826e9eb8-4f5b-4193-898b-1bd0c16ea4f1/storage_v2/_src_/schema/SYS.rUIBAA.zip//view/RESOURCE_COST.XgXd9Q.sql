create view RESOURCE_COST as
select m.name,c.cost
  from sys.resource_cost$ c, sys.resource_map m where
  c.resource# = m.resource#
  and m.type# = 0
  and c.resource# in (2, 4, 7, 8)
/

comment on table RESOURCE_COST is 'Cost for each resource'
/

comment on column RESOURCE_COST.RESOURCE_NAME is 'Name of resource'
/

comment on column RESOURCE_COST.UNIT_COST is 'Cost for resource'
/

