create view PRODUCT_COMPONENT_VERSION as
  (select
substr(banner,1, instr(banner,'Version')-1),
substr(banner, instr(banner,'Version')+8,
instr(banner,' - ')-(instr(banner,'Version')+8)),
substr(banner,instr(banner,' - ')+3)
from v$version
where instr(banner,'Version') > 0
and
((instr(banner,'Version') <   instr(banner,'Release')) or
instr(banner,'Release') = 0))
union
(select
substr(banner,1, instr(banner,'Release')-1),
substr(banner, instr(banner,'Release')+8,
instr(banner,' - ')-(instr(banner,'Release')+8)),
substr(banner,instr(banner,' - ')+3)
from v$version
where instr(banner,'Release') > 0
and
instr(banner,'Release') <   instr(banner,' - '))
/

comment on table PRODUCT_COMPONENT_VERSION is 'version and status information for component products'
/

comment on column PRODUCT_COMPONENT_VERSION.PRODUCT is 'product name'
/

comment on column PRODUCT_COMPONENT_VERSION.VERSION is 'version number'
/

comment on column PRODUCT_COMPONENT_VERSION.STATUS is 'status of release'
/

