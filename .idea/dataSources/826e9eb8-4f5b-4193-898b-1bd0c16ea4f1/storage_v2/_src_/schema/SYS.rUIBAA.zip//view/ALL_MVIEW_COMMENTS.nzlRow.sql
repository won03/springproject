create view ALL_MVIEW_COMMENTS as
select u.name, o.name, c.comment$
from sys.obj$ o, sys.user$ u, sys.com$ c, sys.tab$ t
  where o.owner# = u.user# AND o.type# = 2
  and (bitand(t.property, 67108864) = 67108864)         /*mv container table */
  and o.obj# = c.obj#(+)
  and c.col#(+) is NULL
  and o.obj# = t.obj#
  and (o.owner# = userenv('SCHEMAID')
        or
        o.obj# in ( select obj#
                    from sys.objauth$
                    where grantee# in ( select kzsrorol
                                         from x$kzsro
                                       )
                  )
        or /* user has system privileges */
          exists (select null from v$enabledprivs
                  where priv_number in (-173 /* CREATE ANY MV */,
                                        -174 /* ALTER ANY MV */,
                                        -175 /* DROP ANY MV */)
                  )
      )
/

comment on table ALL_MVIEW_COMMENTS is 'Comments on materialized views accessible to the user'
/

comment on column ALL_MVIEW_COMMENTS.OWNER is 'Owner of the materialized view'
/

comment on column ALL_MVIEW_COMMENTS.MVIEW_NAME is 'Name of the materialized view'
/

comment on column ALL_MVIEW_COMMENTS.COMMENTS is 'Comment on the materialized view'
/

