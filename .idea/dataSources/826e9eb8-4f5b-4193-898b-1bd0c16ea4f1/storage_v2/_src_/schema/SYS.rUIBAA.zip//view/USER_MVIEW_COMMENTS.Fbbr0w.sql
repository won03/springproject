create view USER_MVIEW_COMMENTS as
select o.name, c.comment$
from sys.obj$ o, sys.com$ c, sys.tab$ t
  where o.owner# = userenv('SCHEMAID')
  and o.type# = 2
  and (bitand(t.property, 67108864) = 67108864)         /*mv container table */
  and o.obj# = c.obj#(+)
  and c.col#(+) is NULL
  and o.obj# = t.obj#
/

comment on table USER_MVIEW_COMMENTS is 'Comments on materialized views owned by the user'
/

comment on column USER_MVIEW_COMMENTS.MVIEW_NAME is 'Name of the materialized view'
/

comment on column USER_MVIEW_COMMENTS.COMMENTS is 'Comment on the materialized view'
/

