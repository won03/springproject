create view USER_TAB_COMMENTS as
select o.name,
       decode(o.type#, 0, 'NEXT OBJECT', 1, 'INDEX', 2, 'TABLE', 3, 'CLUSTER',
                      4, 'VIEW', 5, 'SYNONYM', 'UNDEFINED'),
       c.comment$
from sys."_CURRENT_EDITION_OBJ" o, sys.com$ c
where o.owner# = userenv('SCHEMAID')
  and bitand(o.flags,128) = 0
  and (o.type# in (4)                                                /* view */
       or
       (o.type# = 2                                                /* tables */
        AND         /* excluding iot-overflow, nested or mv container tables */
        not exists (select null
                      from sys.tab$ t
                     where t.obj# = o.obj#
                       and (bitand(t.property, 512) = 512 or
                            bitand(t.property, 8192) = 8192 OR
                            bitand(t.property, 67108864) = 67108864))))
  and o.obj# = c.obj#(+)
  and c.col#(+) is null
/

comment on table USER_TAB_COMMENTS is 'Comments on the tables and views owned by the user'
/

comment on column USER_TAB_COMMENTS.TABLE_NAME is 'Name of the object'
/

comment on column USER_TAB_COMMENTS.TABLE_TYPE is 'Type of the object:  "TABLE" or "VIEW"'
/

comment on column USER_TAB_COMMENTS.COMMENTS is 'Comment on the object'
/

