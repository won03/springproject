create view ALL_CLUSTER_HASH_EXPRESSIONS as
select us.name, o.name, c.condition
from sys.cdef$ c, sys.user$ us, sys.obj$ o
where c.type#   = 8
and   c.obj#   = o.obj#
and   us.user# = o.owner#
and   ( us.user# = userenv('SCHEMAID')
        or  /* user has system privilages */
           exists (select null from v$enabledprivs
               where priv_number in (-61 /* CREATE ANY CLUSTER */,
                                     -62 /* ALTER ANY CLUSTER */,
                                     -63 /* DROP ANY CLUSTER */ )
                  )
      )
/

comment on table ALL_CLUSTER_HASH_EXPRESSIONS is 'Hash functions for all accessible clusters'
/

comment on column ALL_CLUSTER_HASH_EXPRESSIONS.OWNER is 'Name of owner of cluster'
/

comment on column ALL_CLUSTER_HASH_EXPRESSIONS.CLUSTER_NAME is 'Name of cluster'
/

comment on column ALL_CLUSTER_HASH_EXPRESSIONS.HASH_EXPRESSION is 'Text of hash function of cluster'
/

