create view USER_CLUSTER_HASH_EXPRESSIONS as
select us.name, o.name, c.condition
from sys.cdef$ c, sys.user$ us, sys.obj$ o
where c.type#   = 8
and   c.obj#   = o.obj#
and   us.user# = o.owner#
and   us.user# = userenv('SCHEMAID')
/

comment on table USER_CLUSTER_HASH_EXPRESSIONS is 'Hash functions for the user''s hash clusters'
/

comment on column USER_CLUSTER_HASH_EXPRESSIONS.OWNER is 'Name of owner of cluster'
/

comment on column USER_CLUSTER_HASH_EXPRESSIONS.CLUSTER_NAME is 'Name of cluster'
/

comment on column USER_CLUSTER_HASH_EXPRESSIONS.HASH_EXPRESSION is 'Text of hash function of cluster'
/

