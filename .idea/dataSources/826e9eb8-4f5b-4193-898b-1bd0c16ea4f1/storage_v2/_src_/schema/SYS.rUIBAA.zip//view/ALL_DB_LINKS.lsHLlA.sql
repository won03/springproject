create view ALL_DB_LINKS as
select u.name, l.name, l.userid, l.host, l.ctime
from sys.link$ l, sys.user$ u
where l.owner# in ( select kzsrorol from x$kzsro )
  and l.owner# = u.user#
/

comment on table ALL_DB_LINKS is 'Database links accessible to the user'
/

comment on column ALL_DB_LINKS.DB_LINK is 'Name of the database link'
/

comment on column ALL_DB_LINKS.USERNAME is 'Name of user to log on as'
/

comment on column ALL_DB_LINKS.HOST is 'SQL*Net string for connect'
/

comment on column ALL_DB_LINKS.CREATED is 'Creation time of the database link'
/

