create view ALL_USERS as
select u.name, u.user#, u.ctime
from sys.user$ u, sys.ts$ dts, sys.ts$ tts
where u.datats# = dts.ts#
  and u.tempts# = tts.ts#
  and u.type# = 1
/

comment on table ALL_USERS is 'Information about all users of the database'
/

comment on column ALL_USERS.USERNAME is 'Name of the user'
/

comment on column ALL_USERS.USER_ID is 'ID number of the user'
/

comment on column ALL_USERS.CREATED is 'User creation date'
/

