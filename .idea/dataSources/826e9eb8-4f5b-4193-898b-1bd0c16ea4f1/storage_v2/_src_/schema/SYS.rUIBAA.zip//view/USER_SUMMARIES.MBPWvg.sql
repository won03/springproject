create view USER_SUMMARIES as
select u.name, o.name, u.name, s.containernam,
       s.lastrefreshscn, s.lastrefreshdate,
       decode (s.refreshmode, 0, 'NONE', 1, 'ANY', 2, 'INCREMENTAL', 3,'FULL'),
       decode(bitand(s.pflags, 25165824), 25165824, 'N', 'Y'),
       s.fullrefreshtim, s.increfreshtim,
       decode(bitand(s.pflags, 48), 0, 'N', 'Y'),
       decode(bitand(s.mflags, 64), 0, 'N', 'Y'), /* QSMQSUM_UNUSABLE */
       decode(bitand(s.pflags, 1294319), 0, 'Y', 'N'),
       decode(bitand((select n.flag2 from sys.snap$ n
                      where n.vname=s.containernam and n.sowner=u.name), 67108864),
                     67108864,  /* primary CUBE mv? */
                     decode(bitand((select n2.flag from sys.snap$ n2
                            where n2.parent_sowner=u.name and n2.parent_vname=s.containernam), 256),
                            256, 'N', 'Y'), /* Its child mv's properties determin INC_REFRESHABLE */
                     decode(bitand(s.pflags, 236879743), 0, 'Y', 'N')),
       decode(bitand(s.mflags, 1), 0, 'N', 'Y'), /* QSMQSUM_KNOWNSTL */
       s.sumtextlen,s.sumtext
from sys.user$ u, sys.sum$ s, sys.obj$ o
where o.owner# = u.user#
  and o.obj# = s.obj#
  and bitand(s.xpflags, 8388608) = 0  /* NOT REWRITE EQUIVALENCE SUMMARY */
  and o.owner# = userenv('SCHEMAID')
/

comment on table USER_SUMMARIES is 'Description of the summaries created by the user'
/

comment on column USER_SUMMARIES.OWNER is 'Owner of the summary'
/

comment on column USER_SUMMARIES.SUMMARY_NAME is 'Name of the summary'
/

comment on column USER_SUMMARIES.CONTAINER_OWNER is 'Owner of the container table'
/

comment on column USER_SUMMARIES.CONTAINER_NAME is 'Name of the container table for this summary'
/

comment on column USER_SUMMARIES.LAST_REFRESH_SCN is 'The SCN of the last transaction to refresh the summary'
/

comment on column USER_SUMMARIES.LAST_REFRESH_DATE is 'The date of the last refresh of the summary'
/

comment on column USER_SUMMARIES.REFRESH_METHOD is 'User declared method of refresh for the summary'
/

comment on column USER_SUMMARIES.SUMMARY is 'Indicates the presence of either aggregation or a GROUP BY'
/

comment on column USER_SUMMARIES.FULLREFRESHTIM is 'The time that it took to fully refresh the summary'
/

comment on column USER_SUMMARIES.INCREFRESHTIM is 'The time that it took to incrementally refresh the summary'
/

comment on column USER_SUMMARIES.CONTAINS_VIEWS is 'This summary contains views in the FROM clause'
/

comment on column USER_SUMMARIES.UNUSABLE is 'This summary is unusable, the build was deferred'
/

comment on column USER_SUMMARIES.RESTRICTED_SYNTAX is 'This summary contains restrictive syntax'
/

comment on column USER_SUMMARIES.INC_REFRESHABLE is 'This summary is not restricted from being incrementally refreshed'
/

comment on column USER_SUMMARIES.KNOWN_STALE is 'This summary is directly stale'
/

