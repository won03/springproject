create view USER_DIMENSIONS as
select u.name, o.name,
       decode(o.status, 5, 'Y', 'N'),
       decode(o.status, 1, 'VALID', 5, 'NEEDS_COMPILE', 'ERROR'),
       1                  /* Metadata revision number */
from sys.dim$ d, sys.obj$ o, sys.user$ u
where o.owner# = u.user#
  and o.obj# = d.obj#
  and o.owner# = userenv('SCHEMAID')
/

comment on table USER_DIMENSIONS is 'Description of the dimension objects accessible to the DBA'
/

comment on column USER_DIMENSIONS.OWNER is 'Owner of the dimension'
/

comment on column USER_DIMENSIONS.DIMENSION_NAME is 'Name of the dimension'
/

comment on column USER_DIMENSIONS.INVALID is 'Invalidity of the dimension, Y = INVALID, N = VALID.
 The column is deprecated, please use COMPILE_STATE instead.'
/

comment on column USER_DIMENSIONS.COMPILE_STATE is 'Compile status of the dimension, VALID/NEEDS_COMPILE/ERROR'
/

comment on column USER_DIMENSIONS.REVISION is 'Revision levle of the dimension'
/

