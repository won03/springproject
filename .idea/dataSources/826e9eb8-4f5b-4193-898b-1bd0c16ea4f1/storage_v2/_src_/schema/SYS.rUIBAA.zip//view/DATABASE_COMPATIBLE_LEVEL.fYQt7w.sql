create view DATABASE_COMPATIBLE_LEVEL as
select value,description
from v$parameter
where name = 'compatible'
/

comment on table DATABASE_COMPATIBLE_LEVEL is 'Database compatible parameter set via init.ora'
/

comment on column DATABASE_COMPATIBLE_LEVEL.VALUE is 'Parameter value'
/

comment on column DATABASE_COMPATIBLE_LEVEL.DESCRIPTION is 'Description of value'
/

