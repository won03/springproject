create view USER_ENCRYPTED_COLUMNS as
select TABLE_NAME, COLUMN_NAME, ENCRYPTION_ALG,SALT, INTEGRITY_ALG from DBA_ENCRYPTED_COLUMNS
  where OWNER = SYS_CONTEXT('USERENV','CURRENT_USER')
/

comment on table USER_ENCRYPTED_COLUMNS is 'Encryption information on columns of tables owned by the user'
/

comment on column USER_ENCRYPTED_COLUMNS.TABLE_NAME is 'Name of the table'
/

comment on column USER_ENCRYPTED_COLUMNS.COLUMN_NAME is 'Name of the column'
/

comment on column USER_ENCRYPTED_COLUMNS.ENCRYPTION_ALG is 'Encryption algorithm used for the column'
/

comment on column USER_ENCRYPTED_COLUMNS.SALT is 'Is this column encrypted with salt? YES or NO'
/

comment on column USER_ENCRYPTED_COLUMNS.INTEGRITY_ALG is 'Integrity algorithm used for the column'
/

