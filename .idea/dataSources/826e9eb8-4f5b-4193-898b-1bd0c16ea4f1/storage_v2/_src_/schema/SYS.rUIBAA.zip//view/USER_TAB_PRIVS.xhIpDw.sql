create view USER_TAB_PRIVS as
select ue.name, u.name, o.name, ur.name, tpm.name,
       decode(mod(oa.option$,2), 1, 'YES', 'NO'),
       decode(bitand(oa.option$,2), 2, 'YES', 'NO')
from sys.objauth$ oa, sys."_CURRENT_EDITION_OBJ" o, sys.user$ u, sys.user$ ur,
     sys.user$ ue, table_privilege_map tpm
where oa.obj# = o.obj#
  and oa.grantor# = ur.user#
  and oa.grantee# = ue.user#
  and oa.col# is null
  and u.user# = o.owner#
  and oa.privilege# = tpm.privilege
  and userenv('SCHEMAID') in (oa.grantor#, oa.grantee#, o.owner#)
/

comment on table USER_TAB_PRIVS is 'Grants on objects for which the user is the owner, grantor or grantee'
/

comment on column USER_TAB_PRIVS.GRANTEE is 'Name of the user to whom access was granted'
/

comment on column USER_TAB_PRIVS.OWNER is 'Owner of the object'
/

comment on column USER_TAB_PRIVS.TABLE_NAME is 'Name of the object'
/

comment on column USER_TAB_PRIVS.GRANTOR is 'Name of the user who performed the grant'
/

comment on column USER_TAB_PRIVS.PRIVILEGE is 'Table Privilege'
/

comment on column USER_TAB_PRIVS.GRANTABLE is 'Privilege is grantable'
/

comment on column USER_TAB_PRIVS.HIERARCHY is 'Privilege is with hierarchy option'
/

