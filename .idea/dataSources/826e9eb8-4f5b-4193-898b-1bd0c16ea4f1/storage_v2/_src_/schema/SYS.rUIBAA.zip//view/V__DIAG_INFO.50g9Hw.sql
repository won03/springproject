create view V_$DIAG_INFO as
select "INST_ID","NAME","VALUE" from v$diag_info
/

