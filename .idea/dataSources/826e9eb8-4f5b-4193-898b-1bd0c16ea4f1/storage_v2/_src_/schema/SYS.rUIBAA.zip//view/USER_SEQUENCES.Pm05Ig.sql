create view USER_SEQUENCES as
select o.name,
      s.minvalue, s.maxvalue, s.increment$,
      decode (s.cycle#, 0, 'N', 1, 'Y'),
      decode (s.order$, 0, 'N', 1, 'Y'),
      s.cache, s.highwater
from sys.seq$ s, sys.obj$ o
where o.owner# = userenv('SCHEMAID')
  and o.obj# = s.obj#
/

comment on table USER_SEQUENCES is 'Description of the user''s own SEQUENCEs'
/

comment on column USER_SEQUENCES.SEQUENCE_NAME is 'SEQUENCE name'
/

comment on column USER_SEQUENCES.MIN_VALUE is 'Minimum value of the sequence'
/

comment on column USER_SEQUENCES.MAX_VALUE is 'Maximum value of the sequence'
/

comment on column USER_SEQUENCES.INCREMENT_BY is 'Value by which sequence is incremented'
/

comment on column USER_SEQUENCES.CYCLE_FLAG is 'Does sequence wrap around on reaching limit?'
/

comment on column USER_SEQUENCES.ORDER_FLAG is 'Are sequence numbers generated in order?'
/

comment on column USER_SEQUENCES.CACHE_SIZE is 'Number of sequence numbers to cache'
/

comment on column USER_SEQUENCES.LAST_NUMBER is 'Last sequence number written to disk'
/

