create view NLS_SESSION_PARAMETERS as
select substr(parameter, 1, 30),
       substr(value, 1, 40)
from v$nls_parameters
where parameter != 'NLS_CHARACTERSET' and
 parameter != 'NLS_NCHAR_CHARACTERSET'
/

comment on table NLS_SESSION_PARAMETERS is 'NLS parameters of the user session'
/

comment on column NLS_SESSION_PARAMETERS.PARAMETER is 'Parameter name'
/

comment on column NLS_SESSION_PARAMETERS.VALUE is 'Parameter value'
/

