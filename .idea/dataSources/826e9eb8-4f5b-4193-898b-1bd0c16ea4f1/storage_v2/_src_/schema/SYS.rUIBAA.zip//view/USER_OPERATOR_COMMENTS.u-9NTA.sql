create view USER_OPERATOR_COMMENTS as
select u.name, o.name, c.comment$
from   sys.obj$ o, sys.operator$ op, sys.com$ c, sys.user$ u
where  o.obj# = op.obj# and c.obj# = op.obj# and u.user# = o.owner#
       and o.owner# = userenv('SCHEMAID')
/

comment on table USER_OPERATOR_COMMENTS is 'Comments for user-defined operators'
/

comment on column USER_OPERATOR_COMMENTS.OWNER is 'Owner of the user-defined operator'
/

comment on column USER_OPERATOR_COMMENTS.OPERATOR_NAME is 'Name of the user-defined operator'
/

comment on column USER_OPERATOR_COMMENTS.COMMENTS is 'Comment for the user-defined operator'
/

