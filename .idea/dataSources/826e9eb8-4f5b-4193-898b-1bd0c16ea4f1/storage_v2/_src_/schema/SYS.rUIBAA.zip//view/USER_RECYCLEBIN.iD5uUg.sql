create view USER_RECYCLEBIN as
select o.name, r.original_name,
       decode(r.operation, 0, 'DROP', 1, 'TRUNCATE', 'UNDEFINED'),
       decode(r.type#, 1, 'TABLE', 2, 'INDEX', 3, 'INDEX',
                       4, 'NESTED TABLE', 5, 'LOB', 6, 'LOB INDEX',
                       7, 'DOMAIN INDEX', 8, 'IOT TOP INDEX',
                       9, 'IOT OVERFLOW SEGMENT', 10, 'IOT MAPPING TABLE',
                       11, 'TRIGGER', 12, 'CONSTRAINT', 13, 'Table Partition',
                       14, 'Table Composite Partition', 15, 'Index Partition',
                       16, 'Index Composite Partition', 17, 'LOB Partition',
                       18, 'LOB Composite Partition',
                       'UNDEFINED'),
       t.name,
       to_char(o.ctime, 'YYYY-MM-DD:HH24:MI:SS'),
       to_char(r.droptime, 'YYYY-MM-DD:HH24:MI:SS'),
       r.dropscn, r.partition_name,
       decode(bitand(r.flags, 4), 0, 'NO', 4, 'YES', 'NO'),
       decode(bitand(r.flags, 2), 0, 'NO', 2, 'YES', 'NO'),
       r.related, r.bo, r.purgeobj, r.space
from sys."_CURRENT_EDITION_OBJ" o, sys.recyclebin$ r, sys.ts$ t
where r.owner# = userenv('SCHEMAID')
  and o.obj# = r.obj#
  and r.ts# = t.ts#(+)
/

comment on table USER_RECYCLEBIN is 'User view of his recyclebin'
/

comment on column USER_RECYCLEBIN.OBJECT_NAME is 'New name of the object'
/

comment on column USER_RECYCLEBIN.ORIGINAL_NAME is 'Original name of the object'
/

comment on column USER_RECYCLEBIN.OPERATION is 'Operation carried out on the object'
/

comment on column USER_RECYCLEBIN.TYPE is 'Type of the object'
/

comment on column USER_RECYCLEBIN.TS_NAME is 'Tablespace Name to which object belongs'
/

comment on column USER_RECYCLEBIN.CREATETIME is 'Timestamp for the creating of the object'
/

comment on column USER_RECYCLEBIN.DROPTIME is 'Timestamp for the dropping of the object'
/

comment on column USER_RECYCLEBIN.DROPSCN is 'SCN of the transaction which moved object to Recycle Bin'
/

comment on column USER_RECYCLEBIN.PARTITION_NAME is 'Partition Name which was dropped'
/

comment on column USER_RECYCLEBIN.CAN_UNDROP is 'User can undrop this object'
/

comment on column USER_RECYCLEBIN.CAN_PURGE is 'User can undrop this object'
/

comment on column USER_RECYCLEBIN.RELATED is 'Parent objects Obj#'
/

comment on column USER_RECYCLEBIN.BASE_OBJECT is 'Base objects Obj#'
/

comment on column USER_RECYCLEBIN.PURGE_OBJECT is 'Obj# for object which gets purged'
/

comment on column USER_RECYCLEBIN.SPACE is 'Number of blocks used by this object'
/

