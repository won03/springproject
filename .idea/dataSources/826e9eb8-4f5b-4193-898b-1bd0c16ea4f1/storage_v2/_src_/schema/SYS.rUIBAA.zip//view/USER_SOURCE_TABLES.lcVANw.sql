create view USER_SOURCE_TABLES as
SELECT DISTINCT
   s.source_schema_name, s.source_table_name
  FROM sys.cdc_change_tables$ s, all_tables t, sys.user$ u
  WHERE s.change_table_schema=t.owner AND
        s.change_table_name=t.table_name AND
        s.change_table_schema = u.name AND
        u.user# = userenv('SCHEMAID')
/

comment on table USER_SOURCE_TABLES is 'Source tables available for Change Data Capture'
/

comment on column USER_SOURCE_TABLES.SOURCE_SCHEMA_NAME is 'Schema of the source table'
/

comment on column USER_SOURCE_TABLES.SOURCE_TABLE_NAME is 'Name of the source table'
/

