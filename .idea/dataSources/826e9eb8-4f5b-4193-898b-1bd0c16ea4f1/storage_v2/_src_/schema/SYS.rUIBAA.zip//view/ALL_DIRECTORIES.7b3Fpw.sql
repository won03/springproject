create view ALL_DIRECTORIES as
select u.name, o.name, d.os_path
from sys.user$ u, sys.obj$ o, sys.dir$ d
where u.user# = o.owner#
  and o.obj# = d.obj#
  and ( o.owner# =  userenv('SCHEMAID')
        or o.obj# in
           (select oa.obj#
            from sys.objauth$ oa
            where grantee# in (select kzsrorol
                               from x$kzsro
                              )
           )
        or exists (select null from v$enabledprivs
                   where priv_number in (-177, /* CREATE ANY DIRECTORY */
                                         -178  /* DROP ANY DIRECTORY */)
                  )
      )
/

comment on table ALL_DIRECTORIES is 'Description of all directories accessible to the user'
/

comment on column ALL_DIRECTORIES.OWNER is 'Owner of the directory (always SYS)'
/

comment on column ALL_DIRECTORIES.DIRECTORY_NAME is 'Name of the directory'
/

comment on column ALL_DIRECTORIES.DIRECTORY_PATH is 'Operating system pathname for the directory'
/

