create view ALL_CLUSTERS as
select u.name, o.name, ts.name,
          mod(c.pctfree$, 100),
          decode(bitand(ts.flags, 32), 32, to_number(NULL), c.pctused$),
          c.size$,c.initrans,c.maxtrans,
          s.iniexts * ts.blocksize, s.extsize * ts.blocksize,
          s.minexts, s.maxexts,
          decode(bitand(ts.flags, 3), 1, to_number(NULL),
                                      s.extpct),
          decode(bitand(ts.flags, 32), 32, to_number(NULL),
           decode(s.lists, 0, 1, s.lists)),
          decode(bitand(ts.flags, 32), 32, to_number(NULL),
           decode(s.groups, 0, 1, s.groups)),
          c.avgchn, decode(c.hashkeys, 0, 'INDEX', 'HASH'),
          decode(c.hashkeys, 0, NULL,
                 decode(c.func, 0, 'COLUMN', 1, 'DEFAULT',
                                2, 'HASH EXPRESSION', 3, 'DEFAULT2', NULL)),
          c.hashkeys,
          lpad(decode(c.degree, 32767, 'DEFAULT', nvl(c.degree,1)),10),
          lpad(decode(c.instances, 32767, 'DEFAULT', nvl(c.instances,1)),10),
          lpad(decode(bitand(c.flags, 8), 8, 'Y', 'N'), 5),
          decode(bitand(s.cachehint, 3), 1, 'KEEP', 2, 'RECYCLE', 'DEFAULT'),
          decode(bitand(s.cachehint, 12)/4, 1, 'KEEP', 2, 'NONE', 'DEFAULT'),
          decode(bitand(s.cachehint, 48)/16, 1, 'KEEP', 2, 'NONE', 'DEFAULT'),
          lpad(decode(bitand(c.flags, 65536), 65536, 'Y', 'N'), 5),
          decode(bitand(c.flags, 8388608), 8388608, 'ENABLED', 'DISABLED')
from sys.user$ u, sys.ts$ ts, sys.seg$ s, sys.clu$ c, sys.obj$ o
where o.owner# = u.user#
  and o.obj#   = c.obj#
  and c.ts#    = ts.ts#
  and c.ts#    = s.ts#
  and c.file#  = s.file#
  and c.block# = s.block#
  and (o.owner# = userenv('SCHEMAID')
       or  /* user has system privilages */
         exists (select null from v$enabledprivs
                 where priv_number in (-61 /* CREATE ANY CLUSTER */,
                                       -62 /* ALTER ANY CLUSTER */,
                                       -63 /* DROP ANY CLUSTER */ )
                )
      )
/

comment on table ALL_CLUSTERS is 'Description of clusters accessible to the user'
/

comment on column ALL_CLUSTERS.OWNER is 'Owner of the cluster'
/

comment on column ALL_CLUSTERS.CLUSTER_NAME is 'Name of the cluster'
/

comment on column ALL_CLUSTERS.TABLESPACE_NAME is 'Name of the tablespace containing the cluster'
/

comment on column ALL_CLUSTERS.PCT_FREE is 'Minimum percentage of free space in a block'
/

comment on column ALL_CLUSTERS.PCT_USED is 'Minimum percentage of used space in a block'
/

comment on column ALL_CLUSTERS.KEY_SIZE is 'Estimated size of cluster key plus associated rows'
/

comment on column ALL_CLUSTERS.INI_TRANS is 'Initial number of transactions'
/

comment on column ALL_CLUSTERS.MAX_TRANS is 'Maximum number of transactions'
/

comment on column ALL_CLUSTERS.INITIAL_EXTENT is 'Size of the initial extent in bytes'
/

comment on column ALL_CLUSTERS.NEXT_EXTENT is 'Size of secondary extents in bytes'
/

comment on column ALL_CLUSTERS.MIN_EXTENTS is 'Minimum number of extents allowed in the segment'
/

comment on column ALL_CLUSTERS.MAX_EXTENTS is 'Maximum number of extents allowed in the segment'
/

comment on column ALL_CLUSTERS.PCT_INCREASE is 'Percentage increase in extent size'
/

comment on column ALL_CLUSTERS.FREELISTS is 'Number of process freelists allocated in this segment'
/

comment on column ALL_CLUSTERS.FREELIST_GROUPS is 'Number of freelist groups allocated in this segment'
/

comment on column ALL_CLUSTERS.AVG_BLOCKS_PER_KEY is 'Average number of blocks containing rows with a given cluster key'
/

comment on column ALL_CLUSTERS.CLUSTER_TYPE is 'Type of cluster: b-tree index or hash'
/

comment on column ALL_CLUSTERS.FUNCTION is 'If a hash cluster, the hash function'
/

comment on column ALL_CLUSTERS.HASHKEYS is 'If a hash cluster, the number of hash keys (hash buckets)'
/

comment on column ALL_CLUSTERS.DEGREE is 'The number of threads per instance for scanning the cluster'
/

comment on column ALL_CLUSTERS.INSTANCES is 'The number of instances across which the cluster is to be scanned'
/

comment on column ALL_CLUSTERS.CACHE is 'Whether the cluster is to be cached in the buffer cache'
/

comment on column ALL_CLUSTERS.BUFFER_POOL is 'The default buffer pool to be used for cluster blocks'
/

comment on column ALL_CLUSTERS.FLASH_CACHE is 'The default flash cache hint to be used for cluster blocks'
/

comment on column ALL_CLUSTERS.CELL_FLASH_CACHE is 'The default cell flash cache hint to be used for cluster blocks'
/

comment on column ALL_CLUSTERS.SINGLE_TABLE is 'Whether the cluster can contain only a single table'
/

comment on column ALL_CLUSTERS.DEPENDENCIES is 'Should we keep track of row level dependencies?'
/

