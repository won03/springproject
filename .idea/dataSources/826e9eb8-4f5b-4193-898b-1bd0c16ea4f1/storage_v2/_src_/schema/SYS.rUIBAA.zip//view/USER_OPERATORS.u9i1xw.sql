create view USER_OPERATORS as
select c.name, b.name, a.numbind from
  sys.operator$ a, sys.obj$ b, sys.user$ c where
  a.obj# = b.obj# and b.owner# = c.user# and
  b.owner# = userenv ('SCHEMAID')
/

comment on table USER_OPERATORS is 'All user operators'
/

comment on column USER_OPERATORS.OWNER is 'Owner of the operator'
/

comment on column USER_OPERATORS.OPERATOR_NAME is 'Name of the operator'
/

comment on column USER_OPERATORS.NUMBER_OF_BINDS is 'Number of bindings associated with the operator'
/

