create view USER_RESUMABLE as
select distinct R.SID as SESSION_ID,
       R.INST_ID as INSTANCE_ID, P.QCINST_ID, P.QCSID,
       R.STATUS, R.TIMEOUT, NVL(T.START_TIME, R.SUSPEND_TIME) as START_TIME,
       R.SUSPEND_TIME, R.RESUME_TIME, R.NAME, Q.SQL_TEXT, R.ERROR_NUMBER,
       R.ERROR_PARAMETER1, R.ERROR_PARAMETER2, R.ERROR_PARAMETER3,
       R.ERROR_PARAMETER4, R.ERROR_PARAMETER5, R.ERROR_MSG
from GV$RESUMABLE R, GV$SESSION S, GV$TRANSACTION T, GV$SQL Q, GV$PX_SESSION P
where S.SID=R.SID and S.INST_ID=R.INST_ID
      and S.SADDR=T.SES_ADDR(+) and S.INST_ID=T.INST_ID(+)
      and S.SQL_ADDRESS=Q.ADDRESS(+) and S.INST_ID=Q.INST_ID(+)
      and S.SADDR=P.SADDR(+) and S.INST_ID=P.INST_ID(+)
      and R.ENABLED='YES' and NVL(T.SPACE(+),'NO')='NO'
      and S.USER# = userenv('SCHEMAID')
/

comment on table USER_RESUMABLE is 'Resumable session information for current user'
/

comment on column USER_RESUMABLE.SESSION_ID is 'Session ID of this resumable session'
/

comment on column USER_RESUMABLE.INSTANCE_ID is 'Instance ID of this resumable session'
/

comment on column USER_RESUMABLE.COORD_INSTANCE_ID is 'Instance number of parallel query coordinator'
/

comment on column USER_RESUMABLE.COORD_SESSION_ID is 'Session number of parallel query coordinator'
/

comment on column USER_RESUMABLE.STATUS is 'Status of this resumable session'
/

comment on column USER_RESUMABLE.TIMEOUT is 'Timeout of this resumable session'
/

comment on column USER_RESUMABLE.START_TIME is 'Start time of the current transaction'
/

comment on column USER_RESUMABLE.SUSPEND_TIME is 'Suspend time of the current statement'
/

comment on column USER_RESUMABLE.RESUME_TIME is 'Resume time of the current statement'
/

comment on column USER_RESUMABLE.NAME is 'Name of this resumable session'
/

comment on column USER_RESUMABLE.SQL_TEXT is 'The current SQL text'
/

comment on column USER_RESUMABLE.ERROR_NUMBER is 'The current error number'
/

comment on column USER_RESUMABLE.ERROR_PARAMETER1 is 'The 1st parameter to the current error message'
/

comment on column USER_RESUMABLE.ERROR_PARAMETER2 is 'The 2nd parameter to the current error message'
/

comment on column USER_RESUMABLE.ERROR_PARAMETER3 is 'The 3rd parameter to the current error message'
/

comment on column USER_RESUMABLE.ERROR_PARAMETER4 is 'The 4th parameter to the current error message'
/

comment on column USER_RESUMABLE.ERROR_PARAMETER5 is 'The 5th parameter to the current error message'
/

comment on column USER_RESUMABLE.ERROR_MSG is 'The current error message'
/

