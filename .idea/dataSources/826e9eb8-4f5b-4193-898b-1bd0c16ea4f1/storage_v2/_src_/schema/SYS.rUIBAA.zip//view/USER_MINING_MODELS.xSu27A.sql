create view USER_MINING_MODELS as
select o.name,
       cast(decode(func, /* Mining Function */
              1, 'CLASSIFICATION',
              2, 'REGRESSION',
              3, 'CLUSTERING',
              4, 'FEATURE_EXTRACTION',
              5, 'ASSOCIATION_RULES',
              6, 'ATTRIBUTE_IMPORTANCE',
                 'UNDEFINED') as varchar2(30)),
       cast(decode(alg, /* Mining Algorithm */
              1, 'NAIVE_BAYES',
              2, 'ADAPTIVE_BAYES_NETWORK',
              3, 'DECISION_TREE',
              4, 'SUPPORT_VECTOR_MACHINES',
              5, 'KMEANS',
              6, 'O_CLUSTER',
              7, 'NONNEGATIVE_MATRIX_FACTOR',
              8, 'GENERALIZED_LINEAR_MODEL',
              9, 'APRIORI_ASSOCIATION_RULES',
             10, 'MINIMUM_DESCRIPTION_LENGTH',
                 'UNDEFINED') as varchar2(30)),
       o.ctime, bdur, msize, c.comment$
from sys.model$ m, sys.obj$ o, sys.com$ c
where o.obj#=m.obj#
  and o.obj#=c.obj#(+)
  and o.type#=82
  and o.owner#=userenv('SCHEMAID')
/

comment on table USER_MINING_MODELS is 'Description of the user''s own models'
/

comment on column USER_MINING_MODELS.MODEL_NAME is 'Name of the model'
/

comment on column USER_MINING_MODELS.MINING_FUNCTION is 'Mining function of the model'
/

comment on column USER_MINING_MODELS.ALGORITHM is 'Algorithm of the model'
/

comment on column USER_MINING_MODELS.CREATION_DATE is 'Creation date of the model'
/

comment on column USER_MINING_MODELS.BUILD_DURATION is 'Model build time (in seconds)'
/

comment on column USER_MINING_MODELS.MODEL_SIZE is 'Model size (in Mb)'
/

comment on column USER_MINING_MODELS.COMMENTS is 'Model comments'
/

