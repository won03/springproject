create view ALL_EDITIONING_VIEWS_AE as
select ev_user.name, ev_obj.name, ev.base_tbl_name, ev_obj.defining_edition
from   sys."_ACTUAL_EDITION_OBJ" ev_obj, sys.ev$ ev, sys.user$ ev_user
where
       /* join EV$ to _ACTUAL_EDITION_OBJ on EV id so we can determine */
       /* name of the EV and id of its owner */
       ev_obj.obj# = ev.ev_obj#
       /* join _ACTUAL_EDITION_OBJ row pertaining to EV to USER$ to get */
       /* EV owner name */
  and  ev_obj.owner# = ev_user.user#
       /* make sure the EV is visible to the current user */
  and  (ev_obj.owner# = userenv('SCHEMAID')
        or ev_obj.obj# in
            (select oa.obj#
             from sys.objauth$ oa
             where oa.grantee# in ( select kzsrorol
                                         from x$kzsro
                                  )
            )
        or /* user has system privileges */
          exists (select null from v$enabledprivs
                  where priv_number in (-45 /* LOCK ANY TABLE */,
                                        -47 /* SELECT ANY TABLE */,
                                        -48 /* INSERT ANY TABLE */,
                                        -49 /* UPDATE ANY TABLE */,
                                        -50 /* DELETE ANY TABLE */)
                  )
      )
/

comment on table ALL_EDITIONING_VIEWS_AE is 'Description of Editioning Views accessible to the user'
/

comment on column ALL_EDITIONING_VIEWS_AE.OWNER is 'Owner of an Editioning View'
/

comment on column ALL_EDITIONING_VIEWS_AE.VIEW_NAME is 'Name of an Editioning View'
/

comment on column ALL_EDITIONING_VIEWS_AE.TABLE_NAME is 'Name of an Editioning View''s base table'
/

comment on column ALL_EDITIONING_VIEWS_AE.EDITION_NAME is 'Name of the Application Edition where the Editioning View is defined'
/

