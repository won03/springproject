create view DBA_TAB_STAT_PREFS as
select u.name, o.name, p.pname, p.valchar
from  sys.optstat_user_prefs$ p, obj$ o, user$ u
where p.obj#=o.obj#
  and u.user#=o.owner#
  and o.type#=2
/

comment on table DBA_TAB_STAT_PREFS is 'Statistics preferences for tables'
/

comment on column DBA_TAB_STAT_PREFS.OWNER is 'Name of the owner'
/

comment on column DBA_TAB_STAT_PREFS.TABLE_NAME is 'Name of the table'
/

comment on column DBA_TAB_STAT_PREFS.PREFERENCE_NAME is 'Preference name'
/

comment on column DBA_TAB_STAT_PREFS.PREFERENCE_VALUE is 'Preference value'
/

