create view USER_IDENTIFIERS as
select i.symrep, i.signature,
decode(i.type#, 1, 'VARIABLE', 2, 'ITERATOR', 3, 'DATE DATATYPE',
                4, 'PACKAGE',  5, 'PROCEDURE', 6, 'FUNCTION', 7, 'FORMAL IN',
                8, 'SUBTYPE',  9, 'CURSOR', 10, 'INDEX TABLE', 11, 'OBJECT',
               12, 'RECORD', 13, 'EXCEPTION', 14, 'BOOLEAN DATATYPE', 15, 'CONSTANT',
               16, 'LIBRARY', 17, 'ASSEMBLY', 18, 'DBLINK', 19, 'LABEL',
               20, 'TABLE', 21, 'NESTED TABLE', 22, 'VARRAY', 23, 'REFCURSOR',
               24, 'BLOB DATATYPE', 25, 'CLOB DATATYPE', 26, 'BFILE DATATYPE',
               27, 'FORMAL IN OUT', 28, 'FORMAL OUT', 29, 'OPAQUE DATATYPE',
               30, 'NUMBER DATATYPE', 31, 'CHARACTER DATATYPE',
               32, 'ASSOCIATIVE ARRAY', 33, 'TIME DATATYPE', 34, 'TIMESTAMP DATATYPE',
               35, 'INTERVAL DATATYPE', 36, 'UROWID', 37, 'SYNONYM', 38, 'TRIGGER',
                   'UNDEFINED'),
o.name,
decode(o.type#, 5, 'SYNONYM', 7, 'PROCEDURE', 8, 'FUNCTION', 9, 'PACKAGE',
                11, 'PACKAGE BODY', 12, 'TRIGGER', 13, 'TYPE', 14, 'TYPE BODY',
                22, 'LIBRARY', 33, 'SPEC OPERATOR', 87, 'ASSEMBLY',
                'UNDEFINED'),
decode(a.action, 1, 'DECLARATION', 2, 'DEFINITION', 3, 'CALL', 4, 'REFERENCE',
                 5, 'ASSIGNMENT', 'UNDEFINED'),
a.action#, a.line, a.col, a.context#
from sys."_CURRENT_EDITION_OBJ" o, sys.plscope_identifier$ i, sys.plscope_action$ a
where i.signature = a.signature
  and o.obj# = a.obj#
  and ( o.type# in (5, 7, 8, 9, 11, 12, 14, 22, 33, 87) OR
       ( o.type# = 13 AND o.subname is null))
  and o.owner# = userenv('SCHEMAID')
/

comment on table USER_IDENTIFIERS is 'Identifiers in stored objects accessible to the user'
/

comment on column USER_IDENTIFIERS.NAME is 'Name of the identifier'
/

comment on column USER_IDENTIFIERS.SIGNATURE is 'Signature of the identifier'
/

comment on column USER_IDENTIFIERS.TYPE is 'Type of the identifier'
/

comment on column USER_IDENTIFIERS.OBJECT_NAME is 'Name of the object where the identifier usage occurred'
/

comment on column USER_IDENTIFIERS.OBJECT_TYPE is 'Type of the object where the identifier usage occurred'
/

comment on column USER_IDENTIFIERS.USAGE is 'Type of the identifier usage'
/

comment on column USER_IDENTIFIERS.USAGE_ID is 'Unique key for an identifier usage within the object'
/

comment on column USER_IDENTIFIERS.LINE is 'Line number of the identifier usage'
/

comment on column USER_IDENTIFIERS.COL is 'Column number of the identifier usage'
/

comment on column USER_IDENTIFIERS.USAGE_CONTEXT_ID is 'Context USAGE_ID of an identifier usage'
/

