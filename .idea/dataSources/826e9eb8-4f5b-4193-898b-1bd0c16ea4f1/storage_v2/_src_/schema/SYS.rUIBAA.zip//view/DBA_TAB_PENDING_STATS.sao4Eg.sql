create view DBA_TAB_PENDING_STATS as
  select u.name, o.name, null, null, h.rowcnt, h.blkcnt, h.avgrln,
         h.samplesize, h.analyzetime
  from   sys.user$ u, sys.obj$ o, sys.wri$_optstat_tab_history h
  where  h.obj# = o.obj# and o.type# = 2 and o.owner# = u.user#
    and  h.savtime > systimestamp
  union all
  -- partitions
  select u.name, o.name, o.subname, null, h.rowcnt, h.blkcnt,
         h.avgrln, h.samplesize, h.analyzetime
  from   sys.user$ u, sys.obj$ o, sys.wri$_optstat_tab_history h
  where  h.obj# = o.obj# and o.type# = 19 and o.owner# = u.user#
    and  h.savtime > systimestamp
  union all
  -- sub partitions
  select u.name, osp.name, ocp.subname, osp.subname, h.rowcnt,
         h.blkcnt, h.avgrln, h.samplesize, h.analyzetime
  from  sys.user$ u,  sys.obj$ osp, obj$ ocp,  sys.tabsubpart$ tsp,
        sys.wri$_optstat_tab_history h
  where h.obj# = osp.obj# and osp.type# = 34 and osp.obj# = tsp.obj# and
        tsp.pobj# = ocp.obj# and osp.owner# = u.user#
    and h.savtime > systimestamp
/

comment on table DBA_TAB_PENDING_STATS is 'Pending statistics of tables, partitions, and subpartitions'
/

comment on column DBA_TAB_PENDING_STATS.OWNER is 'Name of the owner'
/

comment on column DBA_TAB_PENDING_STATS.TABLE_NAME is 'Name of the table'
/

comment on column DBA_TAB_PENDING_STATS.PARTITION_NAME is 'Name of the partition'
/

comment on column DBA_TAB_PENDING_STATS.SUBPARTITION_NAME is 'Name of the subpartition'
/

comment on column DBA_TAB_PENDING_STATS.NUM_ROWS is 'Number of rows'
/

comment on column DBA_TAB_PENDING_STATS.BLOCKS is 'Number of blocks'
/

comment on column DBA_TAB_PENDING_STATS.AVG_ROW_LEN is 'Average row length'
/

comment on column DBA_TAB_PENDING_STATS.SAMPLE_SIZE is 'Sample size'
/

comment on column DBA_TAB_PENDING_STATS.LAST_ANALYZED is 'Time of last analyze'
/

