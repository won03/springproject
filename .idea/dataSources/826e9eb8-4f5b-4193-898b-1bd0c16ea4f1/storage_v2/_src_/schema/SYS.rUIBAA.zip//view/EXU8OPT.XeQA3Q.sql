create view EXU8OPT as
SELECT  parameter, DECODE(value, 'TRUE', 1, 'FALSE', 0, 2)
        FROM    sys.v$option
/

