create procedure apex_admin
as
begin

    f (p=>'4050:3');

end;
/

