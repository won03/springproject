create package wwv_flow_plugin
as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2009. All Rights Reserved.
--
--    NAME
--      wwv_flow_plugin.sql
--
--    DESCRIPTION
--      This package provides all types, constants and APIs for plug-ins.
--
--    RUNTIME DEPLOYMENT: YES
--
--    MODIFIED   (MM/DD/YYYY)
--    pawolf      02/03/2009 - Created based on wwv_flow_plugin
--    pawolf      02/20/2010 - Added support for processes
--    pawolf      04/17/2010 - Renamed lov_items_to_submit and lov_optimize_refresh to ajax_item_to_submit and ajax_optimize_refresh
--    arayner     04/23/2010 - Added "plain_label" attribute to t_page_item record (bug #9557074)
--    pawolf      04/26/2010 - Removed lov_query_result_translated and standard_validations
--
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Public type definitions
--------------------------------------------------------------------------------
type t_plugin is record (
    name         varchar2(45),
    file_prefix  varchar2(4000),
    attribute_01 varchar2(32767),
    attribute_02 varchar2(32767),
    attribute_03 varchar2(32767),
    attribute_04 varchar2(32767),
    attribute_05 varchar2(32767),
    attribute_06 varchar2(32767),
    attribute_07 varchar2(32767),
    attribute_08 varchar2(32767),
    attribute_09 varchar2(32767),
    attribute_10 varchar2(32767) );

type t_page_item is record (
    id                          number,
    name                        varchar2(255),
    label                       varchar2(4000),
    plain_label                 varchar2(4000),
    format_mask                 varchar2(255),
    is_required                 boolean,
    lov_definition              varchar2(4000),
    lov_display_extra           boolean,
    lov_display_null            boolean,
    lov_null_text               varchar2(255),
    lov_null_value              varchar2(255),
    lov_cascade_parent_items    varchar2(255),
    ajax_items_to_submit        varchar2(255),
    ajax_optimize_refresh       boolean,
    element_width               number,
    element_max_length          number,
    element_height              number,
    element_attributes          varchar2(2000),
    element_option_attributes   varchar2(4000),
    escape_output               boolean,
    attribute_01                varchar2(32767),
    attribute_02                varchar2(32767),
    attribute_03                varchar2(32767),
    attribute_04                varchar2(32767),
    attribute_05                varchar2(32767),
    attribute_06                varchar2(32767),
    attribute_07                varchar2(32767),
    attribute_08                varchar2(32767),
    attribute_09                varchar2(32767),
    attribute_10                varchar2(32767) );

type t_page_item_render_result is record (
    is_navigable     boolean default false,
    navigable_dom_id varchar2(255)          /* should only be set if navigable element is not equal to item name */
    );

type t_page_item_ajax_result is record (
    dummy boolean /* not used yet */
    );

type t_page_item_validation_result is record (
    message          varchar2(32767),
    display_location varchar2(40),    /* if not set the application default will be used */
    page_item_name   varchar2(255) ); /* if not set the validated page item name will be used */

type t_region is record (
    id            number,
    static_id     varchar2(255),
    name          varchar2(255),
    type          varchar2(255),
    source        varchar2(32767),
    error_message varchar2(32767),
    attribute_01  varchar2(32767),
    attribute_02  varchar2(32767),
    attribute_03  varchar2(32767),
    attribute_04  varchar2(32767),
    attribute_05  varchar2(32767),
    attribute_06  varchar2(32767),
    attribute_07  varchar2(32767),
    attribute_08  varchar2(32767),
    attribute_09  varchar2(32767),
    attribute_10  varchar2(32767) );

type t_region_render_result is record (
    dummy boolean /* not used yet */
    );

type t_region_ajax_result is record (
    dummy boolean /* not used yet */
    );

type t_dynamic_action is record (
    id           number,
    action       varchar2(50),
    attribute_01 varchar2(32767),
    attribute_02 varchar2(32767),
    attribute_03 varchar2(32767),
    attribute_04 varchar2(32767),
    attribute_05 varchar2(32767),
    attribute_06 varchar2(32767),
    attribute_07 varchar2(32767),
    attribute_08 varchar2(32767),
    attribute_09 varchar2(32767),
    attribute_10 varchar2(32767) );

type t_dynamic_action_render_result is record (
    javascript_function varchar2(32767),
    ajax_identifier     varchar2(255),
    attribute_01        varchar2(32767),
    attribute_02        varchar2(32767),
    attribute_03        varchar2(32767),
    attribute_04        varchar2(32767),
    attribute_05        varchar2(32767),
    attribute_06        varchar2(32767),
    attribute_07        varchar2(32767),
    attribute_08        varchar2(32767),
    attribute_09        varchar2(32767),
    attribute_10        varchar2(32767) );

type t_dynamic_action_ajax_result is record (
    dummy boolean /* not used yet */
    );

type t_process is record (
    id                   number,
    name                 varchar2(255),
    success_message      varchar2(32767),
    attribute_01         varchar2(32767),
    attribute_02         varchar2(32767),
    attribute_03         varchar2(32767),
    attribute_04         varchar2(32767),
    attribute_05         varchar2(32767),
    attribute_06         varchar2(32767),
    attribute_07         varchar2(32767),
    attribute_08         varchar2(32767),
    attribute_09         varchar2(32767),
    attribute_10         varchar2(32767) );

type t_process_exec_result is record (
    success_message varchar2(32767)
    );

--------------------------------------------------------------------------------
-- Public constant definitions
--------------------------------------------------------------------------------

-- plugin types
c_plugin_type_item_type       constant varchar2(30) := 'ITEM TYPE';
c_plugin_type_dynamic_action  constant varchar2(30) := 'DYNAMIC ACTION';
c_plugin_type_validation_type constant varchar2(30) := 'VALIDATION TYPE';
c_plugin_type_region_type     constant varchar2(30) := 'REGION TYPE';
c_plugin_type_report_col_type constant varchar2(30) := 'REPORT COLUMN TYPE';
c_plugin_type_process_type    constant varchar2(30) := 'PROCESS TYPE';

-- attribute scope
c_attribute_scope_application constant varchar2(20) := 'APPLICATION';
c_attribute_scope_component   constant varchar2(20) := 'COMPONENT';

-- used for p_item.standard_validations in render function of page item type
c_std_val_browser             constant varchar2(20) := 'BROWSER';
c_std_val_server              constant varchar2(20) := 'SERVER';
c_std_val_browser_and_server  constant varchar2(20) := 'BROWSER_AND_SERVER';

-- used for display_location in a validation function result of page item type
c_inline_with_field           constant varchar2(40) := 'INLINE_WITH_FIELD';
c_inline_with_field_and_notif constant varchar2(40) := 'INLINE_WITH_FIELD_AND_NOTIFICATION';
c_inline_in_notifiction       constant varchar2(40) := 'INLINE_IN_NOTIFICATION';
c_on_error_page               constant varchar2(40) := 'ON_ERROR_PAGE';

--------------------------------------------------------------------------------
-- Global variables
--------------------------------------------------------------------------------
--
/* Note: for internal use only!!! */
g_page_item_render_result      t_page_item_render_result;
g_page_item_ajax_result        t_page_item_ajax_result;
g_page_item_validation_result  t_page_item_validation_result;
g_region_render_result         t_region_render_result;
g_region_ajax_result           t_region_ajax_result;
g_dynamic_action_render_result t_dynamic_action_render_result;
g_dynamic_action_ajax_result   t_dynamic_action_ajax_result;
g_process_exec_result          t_process_exec_result;

--------------------------------------------------------------------------------
-- Public functions
--------------------------------------------------------------------------------

--==============================================================================
-- Returns the name attribute which has to be used for a HTML input element if
-- you want that the value of the element is stored in session state when the
-- page is submitted. If you have a HTML input element which returns multiple
-- values (eg. select list with multiple="multiple") you have
-- to set p_is_multi_value.
-- Note: This function has to be called before you write something to the
--       HTTP buffer with HTP.P(RN)
--==============================================================================
function get_input_name_for_page_item (
    p_is_multi_value in boolean )
    return varchar2;
--
--==============================================================================
-- Returns the AJAX identifier which has to be used for the on-demand call
-- of a plug-in.
--
-- Note: if the plug-in doesn't have an AJAX callback configured, null will be
--       returned!
--==============================================================================
function get_ajax_identifier return varchar2;
--
end wwv_flow_plugin;
/

