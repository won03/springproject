create view APEX_TEAM_BUGS as
select
    w.PROVISIONING_COMPANY_ID   workspace_id,
    w.short_name                workspace_name,
    --
    b.ID                          bug_id,
    b.BUG_ID                      friendly_bug_number,
    b.BUG_TITLE                   bug_title,
    b.ASSIGNED_TO                 assigned_to,
    b.BUG_SEVERITY                bug_severity,
    b.BUG_STATUS                  bug_status,
    b.PRIORITY                    priority,
    b.FIX_BY_RELEASE              fix_by_release,
    --
    b.ESTIMATED_FIX_DATE,
    b.ACTUAL_FIX_DATE,
    --
    b.BUG_DESCRIPTION,
    b.REPORTED_PLATFORM,
    b.REPORTED_BROWSER,
    b.REPORTED_OPERATING_SYSTEM,
    b.FEATURE_ID                  related_feature_id,
    b.TARGET_MILESTONE_ID         target_milestone_id,
    b.TASK_ID                     related_todo_id,
    b.DUPLICATE_OF_BUG,
    b.TAGS,
    --
    b.CUSTOMER_NAME               customer_name,
    b.CUSTOMER_ISSUE              customer_issue,
    --
    b.COMPONENT                   product_component,
    b.PRODUCT                     product_name,
    b.PRODUCT_VERSION             product_version,
    b.IMPACT                      impact_of_fix,
    b.APPLICATION_ID              application_id,
    b.PAGE_ID                     page_id,
    --
    b.CREATED_BY,
    b.CREATED_ON,
    b.UPDATED_BY,
    b.UPDATED_ON
from
    wwv_flow_bugs b,
    wwv_flow_companies w
where
    b.security_group_id = w.PROVISIONING_COMPANY_ID and
    w.PROVISIONING_COMPANY_ID in (
       select security_group_id
       from   wwv_flow_company_schemas s,
              (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
       where  (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000') or d.sgid = s.security_group_id) ) and
    (user in ('SYS', 'SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_TEAM_BUGS is 'Identifies bugs, also known as software defects.'
/

comment on column APEX_TEAM_BUGS.WORKSPACE_ID is 'Primary key that identifies the workspace.'
/

comment on column APEX_TEAM_BUGS.WORKSPACE_NAME is 'Name of the workspace.'
/

comment on column APEX_TEAM_BUGS.BUG_ID is 'Primary key of the bug.'
/

comment on column APEX_TEAM_BUGS.BUG_TITLE is 'Primary name for this bug.'
/

comment on column APEX_TEAM_BUGS.ASSIGNED_TO is 'Name of developer assigned to fix this bug.'
/

comment on column APEX_TEAM_BUGS.BUG_SEVERITY is 'The severity of this bug.'
/

comment on column APEX_TEAM_BUGS.BUG_STATUS is 'The status of this bug.'
/

comment on column APEX_TEAM_BUGS.PRIORITY is 'The priority assigned to this bug.'
/

comment on column APEX_TEAM_BUGS.FIX_BY_RELEASE is 'The release when this bug should be fixed.'
/

comment on column APEX_TEAM_BUGS.ESTIMATED_FIX_DATE is 'The estimated fix date of the bug.'
/

comment on column APEX_TEAM_BUGS.ACTUAL_FIX_DATE is 'The date the bug was actually fixed.'
/

comment on column APEX_TEAM_BUGS.BUG_DESCRIPTION is 'Detailed description of the bug.'
/

comment on column APEX_TEAM_BUGS.REPORTED_PLATFORM is 'Platform the bug was reported on.'
/

comment on column APEX_TEAM_BUGS.REPORTED_BROWSER is 'Browser being used when bug was noticed.'
/

comment on column APEX_TEAM_BUGS.REPORTED_OPERATING_SYSTEM is 'Operating system the buy was reported on.'
/

comment on column APEX_TEAM_BUGS.RELATED_FEATURE_ID is 'Unique identifier of the related feature.'
/

comment on column APEX_TEAM_BUGS.TARGET_MILESTONE_ID is 'Unique identifier of the milestone for when this bug is targeted to be completed.'
/

comment on column APEX_TEAM_BUGS.RELATED_TODO_ID is 'Unique identifier of related To Do.'
/

comment on column APEX_TEAM_BUGS.DUPLICATE_OF_BUG is 'If this bug is a duplicate of an existing bug, the unique identifier of the other bug.'
/

comment on column APEX_TEAM_BUGS.TAGS is 'Tags associated with this bug.'
/

comment on column APEX_TEAM_BUGS.CUSTOMER_NAME is 'Name of customer reporting this bug.'
/

comment on column APEX_TEAM_BUGS.CUSTOMER_ISSUE is 'A description of the bug as described by the customer.'
/

comment on column APEX_TEAM_BUGS.PRODUCT_COMPONENT is 'Product component (if available) associated with this bug.'
/

comment on column APEX_TEAM_BUGS.PRODUCT_NAME is 'Product associated with this bug.'
/

comment on column APEX_TEAM_BUGS.PRODUCT_VERSION is 'Specifid version of product associated with this bug.'
/

comment on column APEX_TEAM_BUGS.IMPACT_OF_FIX is 'The modules, components or patches that this bug fix will impact.'
/

comment on column APEX_TEAM_BUGS.APPLICATION_ID is 'Associated application.'
/

comment on column APEX_TEAM_BUGS.PAGE_ID is 'Relevant page within associated application.'
/

comment on column APEX_TEAM_BUGS.CREATED_BY is 'Developer who created this bug.'
/

comment on column APEX_TEAM_BUGS.CREATED_ON is 'Date on which this bug was created.'
/

comment on column APEX_TEAM_BUGS.UPDATED_BY is 'Developer who last updated this bug.'
/

comment on column APEX_TEAM_BUGS.UPDATED_ON is 'Date on which this bug was last updated.'
/

