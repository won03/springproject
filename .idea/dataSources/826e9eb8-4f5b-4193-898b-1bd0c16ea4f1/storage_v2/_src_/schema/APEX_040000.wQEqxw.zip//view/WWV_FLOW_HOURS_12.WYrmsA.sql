create view WWV_FLOW_HOURS_12 as
select i from wwv_flow_dual100 where i < 13
/

