create view APEX_UI_DEFAULTS_TABLES as
select schema,
       table_name,
       form_region_title,
       report_region_title,
       created_by,
       created_on,
       last_updated_by,
       last_updated_on
  from wwv_flow_hnt_table_info
 where schema = user
/

comment on table APEX_UI_DEFAULTS_TABLES is 'The User Interface Defaults for the tables within this schema.  Used by the wizards when generating applications.'
/

comment on column APEX_UI_DEFAULTS_TABLES.SCHEMA is 'Schema owning table.'
/

comment on column APEX_UI_DEFAULTS_TABLES.TABLE_NAME is 'Name of table in the schema.'
/

comment on column APEX_UI_DEFAULTS_TABLES.FORM_REGION_TITLE is 'When creating a form based upon this table, this title will be used as the resulting region title.'
/

comment on column APEX_UI_DEFAULTS_TABLES.REPORT_REGION_TITLE is 'When creating a report or tabular form based upon this table, this title will be used as the resulting region title.'
/

comment on column APEX_UI_DEFAULTS_TABLES.CREATED_BY is 'Auditing; user that created the record.'
/

comment on column APEX_UI_DEFAULTS_TABLES.CREATED_ON is 'Auditing; date the record was created.'
/

comment on column APEX_UI_DEFAULTS_TABLES.LAST_UPDATED_BY is 'Auditing; user that last modified the record.'
/

comment on column APEX_UI_DEFAULTS_TABLES.LAST_UPDATED_ON is 'Auditing; date the record was last modified.'
/

