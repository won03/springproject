create view APEX_APPLICATION_PAGE_TREES as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    p.id                             page_id,
    p.name                           page_name,
    t.region_id                      region_id,
    (select plug_name
     from wwv_flow_page_plugs
     where id = t.region_id)         region_name,
    --
    t.id                             tree_id,
    t.TREE_QUERY                     tree_query,
    t.TREE_SOURCE                    tree_source,
    t.TREE_TEMPLATE                  tree_template,
    t.TREE_CLICK_ACTION              tree_click_action,
    t.TREE_START_VALUE               tree_start_value,
    t.TREE_START_ITEM                tree_start_item,
    t.TREE_SELECTED_NODE             tree_selected_node,
    t.SHOW_HINTS                     show_hints,
    t.TREE_HINT_TEXT                 tree_hint_text,
    t.TREE_HAS_FOCUS                 tree_has_focus,
    t.TREE_BUTTON_OPTION             tree_button_option,
    --
    t.LAST_UPDATED_BY                last_updated_by,
    t.LAST_UPDATED_ON                last_updated_on,
    --
    t.TREE_COMMENT                   component_comment,
    --
    p.NAME
    ||' t='||t.TREE_SOURCE
    ||substr(t.TREE_QUERY,1,50)||length(t.tree_query)
    ||' hints='||t.SHOW_HINTS||':'||t.TREE_HINT_TEXT
    ||' links='||t.TREE_CLICK_ACTION
    ||' start='||t.TREE_START_VALUE||':'||t.TREE_START_ITEM
    ||' attributes='||t.TREE_BUTTON_OPTION||':'||t.TREE_HAS_FOCUS||':'||t.TREE_TEMPLATE
    component_signature
from wwv_flow_tree_regions t,
     wwv_flow_steps p,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = p.security_group_id and
      f.id = p.flow_id and
      f.id = t.flow_id and
      p.id = t.page_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_PAGE_TREES is 'Identifies a tree control which can be referenced and displayed by creating a region with a source of this tree'
/

comment on column APEX_APPLICATION_PAGE_TREES.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PAGE_TREES.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PAGE_TREES.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_TREES.PAGE_ID is 'Primary Key of this Application page'
/

comment on column APEX_APPLICATION_PAGE_TREES.PAGE_NAME is 'Page name'
/

comment on column APEX_APPLICATION_PAGE_TREES.REGION_ID is 'Identifies the Page Region foreign key to the apex_application_page_regions view'
/

comment on column APEX_APPLICATION_PAGE_TREES.REGION_NAME is 'Identifies the region name in which this Tree is displayed'
/

comment on column APEX_APPLICATION_PAGE_TREES.TREE_ID is 'Primary Key of this Tree region'
/

comment on column APEX_APPLICATION_PAGE_TREES.TREE_QUERY is 'Query which will be used to generate this tree'
/

comment on column APEX_APPLICATION_PAGE_TREES.TREE_SOURCE is 'Identifies the database table name used as the tree source'
/

comment on column APEX_APPLICATION_PAGE_TREES.TREE_TEMPLATE is 'The template used to display the tree'
/

comment on column APEX_APPLICATION_PAGE_TREES.TREE_CLICK_ACTION is 'Identifies whether node links should be activated on a single or double click action'
/

comment on column APEX_APPLICATION_PAGE_TREES.TREE_START_VALUE is 'Identifies the value of the start item of the tree'
/

comment on column APEX_APPLICATION_PAGE_TREES.TREE_START_ITEM is 'Identifies the database column name to be used as the starting point in the START WITH condition of the tree query'
/

comment on column APEX_APPLICATION_PAGE_TREES.TREE_SELECTED_NODE is 'To save tree state, identifies the last selected node of the tree'
/

comment on column APEX_APPLICATION_PAGE_TREES.SHOW_HINTS is 'Identifes whether to display no tooltip or a tooltip based on a database column or static text'
/

comment on column APEX_APPLICATION_PAGE_TREES.TREE_HINT_TEXT is 'The static text to be used as the tooltip for each node of the tree'
/

comment on column APEX_APPLICATION_PAGE_TREES.TREE_HAS_FOCUS is 'For keyboard navigation, identifies whether tree has focus when page loaded'
/

comment on column APEX_APPLICATION_PAGE_TREES.TREE_BUTTON_OPTION is 'Identifies whether the Collapse All and Expand All buttons are included on the tree page'
/

comment on column APEX_APPLICATION_PAGE_TREES.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPLICATION_PAGE_TREES.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_PAGE_TREES.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_PAGE_TREES.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

