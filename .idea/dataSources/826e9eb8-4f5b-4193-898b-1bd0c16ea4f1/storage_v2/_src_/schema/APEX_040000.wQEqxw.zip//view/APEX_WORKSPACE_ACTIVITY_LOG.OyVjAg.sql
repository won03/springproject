create view APEX_WORKSPACE_ACTIVITY_LOG as
select
           w.short_name              workspace,
           l.userid                  apex_user,
           l.flow_id                 application_id,
           f.name                    application_name,
           f.owner                   application_schema_owner,
           l.step_id                 page_id,
           (select name
            from wwv_flow_steps
            where id = l.step_id and
                  flow_id = f.id)    page_name,
           l.time_stamp              view_date,
           round(86400 * (l.time_stamp - lag(l.time_stamp) over (order by l.time_stamp, l.flow_id, l.userid, l.session_id))) think_time,
           round(86400 * (sysdate - l.time_stamp))     seconds_ago,
           --l.component_type          component_type,
           --l.component_name          component_name,
           l.component_attribute     log_context,
           --l.information             page_view_information,
           l.elap                    elapsed_time,
           l.num_rows                rows_queried,
           l.ip_address              ip_address,
           l.USER_AGENT              agent,
           l.session_id              apex_session_id,
           l.sqlerrm                 error_message,
           l.sqlerrm_component_type  error_on_component_type,
           l.sqlerrm_component_name  error_on_component_name,
           decode(l.page_mode,
             'D','Dynamic',
             'C','Cache Created',
             'R','Cached',
             'P','Partial Page',
             'A','Page Processing',
             l.page_mode)            page_view_mode,
           l.application_info,
           -- ir log
           l.worksheet_id            interactive_report_id,
           l.ir_report_id            ir_saved_report_id,
           l.ir_search               ir_search,
           -- websheet log
           l.websheet_id             ws_application_id,
           l.webpage_id              ws_page_id,
           l.datagrid_id             ws_datagrid_id,
           --
           l.content_length,
           --
           nvl(l.cached_regions,0)   regions_from_cache,
           l.security_group_id       workspace_id
from wwv_flow_activity_log l,
     wwv_flow_companies w,
     wwv_flows f,
     (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (l.security_group_id in (select security_group_id from  wwv_flow_company_schemas where schema = user) or
       user in ('SYS','SYSTEM', 'APEX_040000')  or
       d.sgid = l.security_group_id) and
       --
      l.security_group_id = w.PROVISIONING_COMPANY_ID and
      l.flow_id = f.id(+) and
      l.time_stamp > sysdate - 14 and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_WORKSPACE_ACTIVITY_LOG is 'Page view activity log detail.  One row is logged for each page view for application with logging enabled.'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.APEX_USER is 'Name of the end user of the application'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.APPLICATION_SCHEMA_OWNER is 'Parsing Schema of the Application'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.PAGE_ID is 'ID of the application page'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.PAGE_NAME is 'Name of the application page'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.VIEW_DATE is 'Date of page view with precision to the second'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.THINK_TIME is 'Think time in seconds by application and user with second level granularity'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.LOG_CONTEXT is 'Context of Page View'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.ELAPSED_TIME is 'Elapsed time to generate page source'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.ROWS_QUERIED is 'Number of rows fetched by the APEX reporting engine'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.IP_ADDRESS is 'IP Address for this page view'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.AGENT is 'HTTP User Agent for this page view'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.APEX_SESSION_ID is 'APEX Session ID for this page view'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.ERROR_MESSAGE is 'Error message raised for this page view'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.ERROR_ON_COMPONENT_TYPE is 'The component type that caused an error to be raised'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.ERROR_ON_COMPONENT_NAME is 'The component name which caused the error to be raised'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.PAGE_VIEW_MODE is 'The page view mode, typically Static or Dynamic'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.APPLICATION_INFO is 'Information provided by the application to provide additional application context'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.INTERACTIVE_REPORT_ID is 'Identifies the Interactive Report ID foreign key to the APEX_APPLICATION_PAGE_IR view'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.IR_SAVED_REPORT_ID is 'Identifies the Saved Interactive Report ID foreign key to the APEX_APPLICATION_PAGE_IR_RPT view'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.IR_SEARCH is 'The search text entered from Interactive Report search bar'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.WS_APPLICATION_ID is 'Websheet application primary key, unique over all workspaces'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.WS_PAGE_ID is 'ID of the Websheet application page'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.WS_DATAGRID_ID is 'ID of the Websheet application Data Grid'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.CONTENT_LENGTH is 'The size of the web page served.'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.REGIONS_FROM_CACHE is 'Count of regions on this page that are rendered from cache'
/

comment on column APEX_WORKSPACE_ACTIVITY_LOG.WORKSPACE_ID is 'Primary Key of the Workspace'
/

