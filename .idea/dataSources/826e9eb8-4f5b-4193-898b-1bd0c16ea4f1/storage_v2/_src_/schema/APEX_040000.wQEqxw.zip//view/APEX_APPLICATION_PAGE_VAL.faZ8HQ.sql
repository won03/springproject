create view APEX_APPLICATION_PAGE_VAL as
select
     w.short_name                  workspace,
     p.flow_id                     application_id,
     f.name                        application_name,
     p.id                          page_id,
     p.name                        page_name,
     --
     v.VALIDATION_NAME             validation_name,
     v.VALIDATION_SEQUENCE         validation_sequence,
     v.TABULAR_FORM_REGION_ID      tabular_form_region_id,
     --
     decode(v.VALIDATION_TYPE,
        'EXISTS','Exists',
        'FUNC_BODY_RETURNING_BOOLEAN','Function Returning Boolean',
        'FUNC_BODY_RETURNING_ERR_TEXT','Function Returning Error Text',
        'ITEM_NOT_NULL','Item specified is NOT NULL',
        'ITEM_IN_VALIDATION_CONTAINS_AT_LEAST_ONE_CHAR_IN_STRING2','Item in Expression 1 contains at least one of the characters in Expression 2',
        'ITEM_IN_VALIDATION_CONTAINS_ONLY_CHAR_IN_STRING2','Item in Expression 1 contains only characters in Expression 2',
        'ITEM_IN_VALIDATION_NOT_EQ_STRING2','Item in Expression 1 does NOT equal string literal in Expression2',
        'ITEM_IN_VALIDATION_CONTAINS_NO_CHAR_IN_STRING2','Item in Expression 1 does not contain any of the characters in Expression 2',
        'ITEM_IN_VALIDATION_EQ_STRING2','Item in Expression 1 equals string literal in Expression 2',
        'ITEM_IN_VALIDATION_NOT_IN_STRING2','Item in Expression 1 is NOT contained in Expression 2',
        'ITEM_IN_VALIDATION_IN_STRING2','Item in Expression 1 is contained in Expression 2',
        'ITEM_NOT_ZERO','Item specified is NOT zero',
        'ITEM_CONTAINS_NO_SPACES','Item specified contains no spaces',
        'ITEM_NOT_NULL_OR_ZERO','Item specified is NOT NULL or zero',
        'ITEM_IS_ALPHANUMERIC','Item specified is alphanumeric',
        'ITEM_IS_NUMERIC','Item specified is numeric',
        'ITEM_IS_DATE','Item specified is a valid date',
        'ITEM_IS_TIMESTAMP','Item specified is a valid timestamp',
        'NOT_EXISTS','NOT Exists',
        'PLSQL_ERROR','PL/SQL Error',
        'PLSQL_EXPRESSION','PL/SQL Expression',
        'REGULAR_EXPRESSION','Regular Expression',
        'SQL_EXPRESION','SQL Expression',
         v.VALIDATION_TYPE)        validation_type,
     v.VALIDATION                  validation_expression1,
     v.VALIDATION2                 validation_expression2,
     --
     case nvl(v.always_execute, 'N')
       when 'Y' then 'Yes'
       when 'N' then 'No'
     end                           always_execute,
     nvl((select r from apex_standard_conditions where d = v.VALIDATION_CONDITION_TYPE),v.VALIDATION_CONDITION_TYPE)
                                   condition_type,
     v.VALIDATION_CONDITION        condition_expression1,
     v.VALIDATION_CONDITION2       condition_expression2,
     --
     (select button_name
      from wwv_flow_step_buttons
      where id = v.WHEN_BUTTON_PRESSED
      union
      select name
      from wwv_flow_step_items
      where id = v.WHEN_BUTTON_PRESSED)
                                   when_button_pressed,
     v.WHEN_BUTTON_PRESSED         when_button_pressed_id,
     --
     v.ERROR_MESSAGE               validation_failure_text,
     (select name from wwv_flow_step_items
      where id = v.ASSOCIATED_ITEM and
            flow_id = f.id)        associated_item,
     v.associated_column           associated_column,
     v.ERROR_DISPLAY_LOCATION      error_display_location,
     (select case when v.required_patch > 0 then PATCH_NAME else '{Not '||PATCH_NAME||'}' end PATCH_NAME
     from wwv_flow_patches
     where id= abs(v.REQUIRED_PATCH))   build_option,
     --
     decode(substr(v.SECURITY_SCHEME,1,1),'!','Not ')||
     nvl((select name
     from    wwv_flow_security_schemes
     where   to_char(id) = ltrim(v.SECURITY_SCHEME,'!')
     and     flow_id = f.id),
     v.SECURITY_SCHEME)            authorization_scheme,
     v.SECURITY_SCHEME             authorization_scheme_id,
     --
     v.LAST_UPDATED_BY             last_updated_by,
     v.LAST_UPDATED_ON             last_updated_on,
     v.VALIDATION_COMMENT          component_comment,
     v.id                          validation_id,
     'seq='||v.VALIDATION_SEQUENCE
     ||',item='||(select name from wwv_flow_step_items where id=v.ASSOCIATED_ITEM)
     ||',type='||v.VALIDATION_TYPE
     ||',val='||substr(v.VALIDATION,1,40)||'.'||length(v.VALIDATION)||'.'
      ||substr(v.VALIDATION2,1,40)||'.'||length(v.VALIDATION2)||'.'
     ||decode(v.VALIDATION_CONDITION_TYPE,null,null,',cond='||v.VALIDATION_CONDITION_TYPE||'.'||
         substr(v.VALIDATION_CONDITION,1,30)||length(v.VALIDATION_CONDITION)||'.'||
         substr(v.VALIDATION_CONDITION2,1,30)||length(v.VALIDATION_CONDITION2))
     component_signature
from wwv_flow_step_validations v,
     wwv_flow_steps p,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = p.security_group_id and
      f.security_group_id = v.security_group_id and
      f.id = p.flow_id and
      f.id = v.flow_id and
      p.id = v.flow_step_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_PAGE_VAL is 'Identifies Validations associated with an Application Page'
/

comment on column APEX_APPLICATION_PAGE_VAL.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PAGE_VAL.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PAGE_VAL.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_VAL.PAGE_ID is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_VAL.PAGE_NAME is 'Identifies a page within an application'
/

comment on column APEX_APPLICATION_PAGE_VAL.VALIDATION_NAME is 'Identifies the name of the validation'
/

comment on column APEX_APPLICATION_PAGE_VAL.VALIDATION_SEQUENCE is 'Identifies the sequence in which this validation will be considered for execution'
/

comment on column APEX_APPLICATION_PAGE_VAL.TABULAR_FORM_REGION_ID is 'Identifies the region ID of the tabular form region for column validations'
/

comment on column APEX_APPLICATION_PAGE_VAL.VALIDATION_TYPE is 'Specifies predefined validation type with the corresponding appropriate values in the Expression 1 and Expression 2 fields.'
/

comment on column APEX_APPLICATION_PAGE_VAL.VALIDATION_EXPRESSION1 is 'Identifies the validation which corresponds to the specified Validation Type'
/

comment on column APEX_APPLICATION_PAGE_VAL.VALIDATION_EXPRESSION2 is 'Identifies the validation which corresponds to the specified Validation Type'
/

comment on column APEX_APPLICATION_PAGE_VAL.ALWAYS_EXECUTE is 'If set to Yes this flag will overwrites the "Execute Validations" flag for buttons and always execute the validation.'
/

comment on column APEX_APPLICATION_PAGE_VAL.CONDITION_TYPE is 'Identifies the condition type used to conditionally execute the Page Validation'
/

comment on column APEX_APPLICATION_PAGE_VAL.CONDITION_EXPRESSION1 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PAGE_VAL.CONDITION_EXPRESSION2 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PAGE_VAL.WHEN_BUTTON_PRESSED is 'This validation will only be evaluated if the identified button is pressed'
/

comment on column APEX_APPLICATION_PAGE_VAL.WHEN_BUTTON_PRESSED_ID is 'Foreign key to button'
/

comment on column APEX_APPLICATION_PAGE_VAL.VALIDATION_FAILURE_TEXT is 'Specifies the text that will be displayed in the event the validation raises an error'
/

comment on column APEX_APPLICATION_PAGE_VAL.ASSOCIATED_ITEM is 'If applicable, select the item associated with this validation error message.'
/

comment on column APEX_APPLICATION_PAGE_VAL.ASSOCIATED_COLUMN is 'If applicable, select the column associated with this validation error message.'
/

comment on column APEX_APPLICATION_PAGE_VAL.ERROR_DISPLAY_LOCATION is 'The Error display location identifies where the validation error message will display. Messages can be displayed on an error page, or inline with the existing page. Inline validations are displayed in the "notification" area (defined as part of the page template), and/or within the item label.'
/

comment on column APEX_APPLICATION_PAGE_VAL.BUILD_OPTION is 'Page Computation will be considered for execution if the Build Option is enabled'
/

comment on column APEX_APPLICATION_PAGE_VAL.AUTHORIZATION_SCHEME is 'An authorization scheme must evaluate to TRUE in order for this validation to be considered for execution'
/

comment on column APEX_APPLICATION_PAGE_VAL.AUTHORIZATION_SCHEME_ID is 'Foreign Key'
/

comment on column APEX_APPLICATION_PAGE_VAL.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPLICATION_PAGE_VAL.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_PAGE_VAL.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_PAGE_VAL.VALIDATION_ID is 'Primary key of this page validation'
/

comment on column APEX_APPLICATION_PAGE_VAL.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

