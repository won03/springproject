create view APEX_APPLICATION_PAGE_IR_COL as
select
w.short_name                workspace,
f.id                        application_id,
f.name                      application_name,
c.page_id                   page_id,
ir.id                       interactive_report_id,
ir.region_id                region_id,
c.id                        column_id,
c.db_column_name            column_alias,
c.display_order             display_order,
(select name from wwv_flow_worksheet_col_groups where id = c.group_id) column_group,
c.group_id                  column_group_id,
c.report_label              report_label,
c.column_label              form_label,
c.column_link               ,
c.column_linktext           ,
c.column_link_attr          ,
c.column_link_checksum_type ,
--
decode(c.allow_sorting     ,'Y','Yes','N','No',c.allow_sorting     ) allow_sorting     ,
decode(c.allow_filtering   ,'Y','Yes','N','No',c.allow_filtering   ) allow_filtering   ,
decode(c.allow_highlighting   ,'Y','Yes','N','No',c.allow_highlighting) allow_highlighting,
decode(c.allow_ctrl_breaks ,'Y','Yes','N','No',c.allow_ctrl_breaks ) allow_ctrl_breaks ,
decode(c.allow_aggregations,'Y','Yes','N','No',c.allow_aggregations) allow_aggregations,
decode(c.allow_computations,'Y','Yes','N','No',c.allow_computations) allow_computations,
decode(c.allow_charting    ,'Y','Yes','N','No',c.allow_charting    ) allow_charting    ,
decode(c.allow_group_by    ,'Y','Yes','N','No',c.allow_group_by    ) allow_group_by    ,
decode(c.allow_hide        ,'Y','Yes','N','No',c.allow_hide        ) allow_hide        ,
--
c.column_type               ,
c.display_text_as           ,
c.heading_alignment         ,
c.column_alignment          ,
c.format_mask               ,
tz_dependent                ,
--
decode(c.rpt_show_filter_lov,
       'D','Default Based on Column Type',
       'S','Use Defined List of Values to Filter Exact Match',
       'C','Use Defined List of Values to Filter Word Contains',
       '1','Use Named List of Values to Filter Exact Match',
       '2','Use Named List of Values to Filter Word Contains',
       'N','None',
       c.rpt_show_filter_lov)
                            filter_lov_source,
(select lov_name
   from wwv_flow_lists_of_values$
  where id = c.rpt_named_lov
)                           named_lov,
c.rpt_lov                   ,
c.rpt_filter_date_ranges    filter_date_ranges,
--
c.display_condition_type    ,
c.display_condition         ,
c.display_condition2        ,
--
c.help_text                 ,
--
decode(substr(c.SECURITY_SCHEME,1,1),'!','Not ')||
nvl((select name
 from   wwv_flow_security_schemes
 where  to_char(id) = ltrim(c.SECURITY_SCHEME,'!')
 and    flow_id = f.id),
 c.SECURITY_SCHEME)             authorization_scheme,
c.security_scheme               authorization_scheme_id,
c.column_expr,
c.column_comment                component_comment,
--
c.created_on,
c.created_by,
c.updated_on,
c.updated_by,
--
'Interactive Report Column-'||
c.db_column_name||
' s='||c.display_order||
' g='||(select name from wwv_flow_worksheet_col_groups where id = c.group_id)||
' l='||c.report_label||
substr(c.column_label,1,30)||
substr(c.column_link,1,30)||
substr(c.column_linktext,1,30)||
substr(c.column_link_attr,1,30)||
c.column_link_checksum_type||
c.allow_sorting||
c.allow_filtering||
c.allow_highlighting||
c.allow_ctrl_breaks||
c.allow_aggregations||
c.allow_computations||
c.allow_charting||
c.allow_group_by||
c.allow_hide||
c.column_type||
c.display_text_as||
' ha='||c.heading_alignment||
' ca='||c.column_alignment||
' f='||c.format_mask||
c.rpt_show_filter_lov||
' lov='||length(c.rpt_lov)||
' d='||c.rpt_filter_date_ranges||
' cond='||c.display_condition_type||
length(c.display_condition)||
length(c.display_condition2)||
' h='||length(c.help_text)||
' as='||decode(substr(c.SECURITY_SCHEME,1,1),'!','Not ')||
nvl((select name
 from   wwv_flow_security_schemes
 where  to_char(id) = ltrim(c.SECURITY_SCHEME,'!')
 and    flow_id = f.id),
 c.SECURITY_SCHEME)
component_signature
from wwv_flow_worksheet_columns c,
     wwv_flow_worksheets ir,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = c.security_group_id and
      f.id = ir.flow_id and ir.id = c.worksheet_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_PAGE_IR_COL is 'Report column definitions for interactive report columns'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.PAGE_ID is 'Identifies the page'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.INTERACTIVE_REPORT_ID is 'ID of the interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.REGION_ID is 'ID of the interactive report region'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.COLUMN_ID is 'ID of this column'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.COLUMN_ALIAS is 'Database column name or expression to use in SQL query when displaying this worksheet column'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.DISPLAY_ORDER is 'Default display order of this column'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.COLUMN_GROUP is 'Name of the column group for this column'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.COLUMN_GROUP_ID is 'ID of the column group for this column'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.REPORT_LABEL is 'Report heading label to use for this column'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.FORM_LABEL is 'Single row view label to use for this column'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.COLUMN_LINK is 'Optional link target for this column'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.COLUMN_LINKTEXT is 'Text do display if a link is defined'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.COLUMN_LINK_ATTR is 'Link attributes for the column link.  Displayed within the HTML "A" tag'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.COLUMN_LINK_CHECKSUM_TYPE is 'An appropriate checksum when linking to protected pages'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.ALLOW_SORTING is 'Determines whether to allow sorting for this column.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.ALLOW_FILTERING is 'Determines whether to allow filtering for this column.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.ALLOW_HIGHLIGHTING is 'Determines whether to allow highlighting for this column.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.ALLOW_CTRL_BREAKS is 'Determines whether to allow control breaks for this column.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.ALLOW_AGGREGATIONS is 'Determines whether to allow aggregations for this column.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.ALLOW_COMPUTATIONS is 'Determines whether to allow computations for this column.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.ALLOW_CHARTING is 'Determines whether to allow charting for this column.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.ALLOW_GROUP_BY is 'Determines whether to allow group by for this column.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.ALLOW_HIDE is 'Determines whether to allow hiding this column.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.COLUMN_TYPE is 'Type of data in this column'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.DISPLAY_TEXT_AS is 'Format to display this column'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.HEADING_ALIGNMENT is 'Horizontal alignment of this column''s report heading'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.COLUMN_ALIGNMENT is 'Horizontal alignment of this column''s report data'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.FORMAT_MASK is 'Format mask for this column'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.TZ_DEPENDENT is 'Column is time zone dependent'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.FILTER_LOV_SOURCE is 'Query used to retrieve a list of values for the interactive report.  Displayed in the column header dropdowns, and during filter and highlight creation.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.NAMED_LOV is 'Identifies the Shared List of Values to be used to display and filter this report column'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.RPT_LOV is 'LOV query to display in filter dropdown'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.FILTER_DATE_RANGES is 'Determines the range of dates to display for filters on this column'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.DISPLAY_CONDITION_TYPE is 'For conditionally displayed this column; identifies the condition type to evaluate'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.DISPLAY_CONDITION is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.DISPLAY_CONDITION2 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.HELP_TEXT is 'Descriptive help text for this column, displayed when a user clicks on the column information icon'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.AUTHORIZATION_SCHEME is 'Optional authorization scheme determining whether this column and data is available to a user'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.AUTHORIZATION_SCHEME_ID is 'ID of the authorization scheme'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.COLUMN_EXPR is 'Attribute for internal use only'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.COMPONENT_COMMENT is 'Developer Comment'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.CREATED_ON is 'Auditing; date the record was created.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.CREATED_BY is 'Auditing; user that created the record.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.UPDATED_ON is 'Auditing; date the record was last modified.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.UPDATED_BY is 'Auditing; user that last modified the record.'
/

comment on column APEX_APPLICATION_PAGE_IR_COL.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

