create view APEX_APPLICATION_PAGE_DA as
select  w.short_name                                            workspace,
        e.flow_id                                               application_id,
        f.name                                                  application_name,
        e.page_id                                               page_id,
        p.name                                                  page_name,
        --
        e.name                                                  dynamic_action_name,
        e.event_sequence                                        dynamic_action_sequence,
        e.triggering_element                                    when_element,
        decode(e.triggering_element_type,
            'ITEM',             'Item',
            'REGION',           'Region',
            'COLUMN',           'Column',
            'DOM_OBJECT',       'DOM Object',
            'JQUERY_SELECTOR',  'jQuery Selector',
                                e.triggering_element_type)      when_selection_type,
        nvl((select plug_name
               from wwv_flow_page_plugs
              where id = e.triggering_region_id),
            e.triggering_region_id)                             when_region,
        e.triggering_region_id                                  when_region_id,
        --
        decode(e.triggering_condition_type,
            'EQUALS',               'equal to',
            'NOT_EQUALS',           'not equal to',
            'GREATER_THAN',         'greater than',
            'GREATER_THAN_OR_EQUAL','greater than or equal to',
            'LESS_THAN',            'less than',
            'LESS_THAN_OR_EQUAL',   'less than or equal to',
            'NULL',                 'is null',
            'NOT_NULL',             'is not null',
            'IN_LIST',              'in list',
            'NOT_IN_LIST',          'not in list',
            'JAVASCRIPT_EXPRESSION','JavaScript expression',
                                    e.triggering_condition_type)when_condition,
        e.triggering_expression                                 when_expression,
        --
        e.bind_type                                             when_event_scope,
        e.bind_event_type                                       when_event_internal_name,
        (select d
          from wwv_flow_javascript_events
         where r = e.bind_event_type)                           when_event_name,
        --
        nvl((select r
               from apex_standard_conditions
              where d = e.display_when_type),
            e.display_when_type)                                condition_type,
        e.display_when_cond                                     condition_expression1,
        e.display_when_cond2                                    condition_expression2,
        --
        (select case when e.required_patch > 0 then
                    patch_name
                else
                    '{Not '||patch_name||'}'
                end patch_name
           from wwv_flow_patches
          where id = abs(e.required_patch))                     build_option,
        e.required_patch                                        build_option_id,
        --
        decode(substr(e.security_scheme,1,1),'!','Not ')||
        nvl((select name
               from wwv_flow_security_schemes
              where to_char(id) = ltrim(e.security_scheme,'!')
                and flow_id = e.id),
            e.security_scheme)                                  authorization_scheme,
        e.security_scheme                                       authorization_scheme_id,
        --
        e.last_updated_on                                       last_updated_on,
        e.last_updated_by                                       last_updated_by,
        e.da_event_comment                                      component_comment,
        e.id                                                    dynamic_action_id,
        --
        (select count(*)
           from wwv_flow_page_da_actions
          where event_id = e.id)                                number_of_actions,
        --
        'name='     || e.name ||
        ',seq='     || lpad(e.event_sequence,5,'00000') ||
        ',tee='     || substr(e.triggering_element,1,30) ||
        ',teet='    || e.triggering_element_type ||
        ',ter='     || nvl( (select plug_name
                              from wwv_flow_page_plugs
                             where id=e.triggering_region_id),
                            e.triggering_region_id) ||
        ',tec='     || e.triggering_condition_type ||
        ',teexp='   || substr(e.triggering_expression,1,30) ||
        ',tebt='    || e.bind_type ||
        ',tebe='    || e.bind_event_type ||
        ',cond='    || e.display_when_type ||
                       substr(e.display_when_cond,1,20) ||
                       length(e.display_when_cond) ||
                       length(e.display_when_cond2) ||
        ',build='   || nvl( (select patch_name
                               from wwv_flow_patches
                              where id = abs(e.required_patch)),
                            e.required_patch) ||
        ' auth='    || decode(substr(e.security_scheme,1,1),'!','Not ')||
                       nvl( (select name
                              from wwv_flow_security_schemes
                             where to_char(id)= ltrim(e.security_scheme,'!')
                               and flow_id = e.id),
                            e.security_scheme)                  component_signature
  from  wwv_flow_page_da_events e,
        wwv_flow_steps p,
        wwv_flows f,
        wwv_flow_companies w,
        wwv_flow_company_schemas s,
        (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
 where  (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
        f.security_group_id = w.PROVISIONING_COMPANY_ID and
        s.security_group_id = w.PROVISIONING_COMPANY_ID and
        s.schema = f.owner and
        f.security_group_id = p.security_group_id and
        f.security_group_id = e.security_group_id and
        f.id = p.flow_id and
        f.id = e.flow_id and
        p.id = e.page_id and
        (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
        w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_PAGE_DA is 'Identifies Dynamic Actions associated with a Page'
/

comment on column APEX_APPLICATION_PAGE_DA.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PAGE_DA.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PAGE_DA.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_DA.PAGE_ID is 'Identifies page number'
/

comment on column APEX_APPLICATION_PAGE_DA.PAGE_NAME is 'Identifies a page within an application'
/

comment on column APEX_APPLICATION_PAGE_DA.DYNAMIC_ACTION_NAME is 'Identifies the name of the Dynamic Action'
/

comment on column APEX_APPLICATION_PAGE_DA.DYNAMIC_ACTION_SEQUENCE is 'Identifies the sequence the Dynamic Action is executed'
/

comment on column APEX_APPLICATION_PAGE_DA.WHEN_ELEMENT is 'Identifies the element(s) that will be the trigger for the Dynamic Action'
/

comment on column APEX_APPLICATION_PAGE_DA.WHEN_SELECTION_TYPE is 'Identifies the type of selector used for the When Element'
/

comment on column APEX_APPLICATION_PAGE_DA.WHEN_REGION is 'Identifies the name of the region containing the When Element(s)'
/

comment on column APEX_APPLICATION_PAGE_DA.WHEN_REGION_ID is 'Identifies the ID of the region containing the When Element(s)'
/

comment on column APEX_APPLICATION_PAGE_DA.WHEN_CONDITION is 'Identifies the optional condition that can be used to control when the Action''s fire'
/

comment on column APEX_APPLICATION_PAGE_DA.WHEN_EXPRESSION is 'Identifies the condition expression used to control when the Action''s fire'
/

comment on column APEX_APPLICATION_PAGE_DA.WHEN_EVENT_SCOPE is 'Identifies the scope of the event, can be either ''bind'', ''live'' or ''once'''
/

comment on column APEX_APPLICATION_PAGE_DA.WHEN_EVENT_INTERNAL_NAME is 'Identifies the internal name of the event that is used to define when the dynamic action fires'
/

comment on column APEX_APPLICATION_PAGE_DA.WHEN_EVENT_NAME is 'Identifies the display name of the event that is used to define when the dynamic action fires'
/

comment on column APEX_APPLICATION_PAGE_DA.CONDITION_TYPE is 'Identifies a condition that must be met in order for this Dynamic Action to be processed'
/

comment on column APEX_APPLICATION_PAGE_DA.CONDITION_EXPRESSION1 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PAGE_DA.CONDITION_EXPRESSION2 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PAGE_DA.BUILD_OPTION is 'Dynamic Action will be processed if the Build Option is enabled'
/

comment on column APEX_APPLICATION_PAGE_DA.BUILD_OPTION_ID is 'Foreign Key'
/

comment on column APEX_APPLICATION_PAGE_DA.AUTHORIZATION_SCHEME is 'An authorization scheme must evaluate to TRUE in order for this Dynamic Action to be processed'
/

comment on column APEX_APPLICATION_PAGE_DA.AUTHORIZATION_SCHEME_ID is 'Foreign Key'
/

comment on column APEX_APPLICATION_PAGE_DA.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_PAGE_DA.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPLICATION_PAGE_DA.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_PAGE_DA.DYNAMIC_ACTION_ID is 'Primary Key of this Dynamic Action'
/

comment on column APEX_APPLICATION_PAGE_DA.NUMBER_OF_ACTIONS is 'Number of Actions defined for this Dynamic Action'
/

comment on column APEX_APPLICATION_PAGE_DA.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

