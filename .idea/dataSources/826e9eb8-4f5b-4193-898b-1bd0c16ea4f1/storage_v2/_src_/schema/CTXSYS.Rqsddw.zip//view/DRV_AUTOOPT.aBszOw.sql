create view DRV$AUTOOPT as
select "AOI_IDXID","AOI_PARTID","AOI_OWNID","AOI_OWNNAME","AOI_IDXNAME","AOI_PARTNAME" from dr$autoopt
/

