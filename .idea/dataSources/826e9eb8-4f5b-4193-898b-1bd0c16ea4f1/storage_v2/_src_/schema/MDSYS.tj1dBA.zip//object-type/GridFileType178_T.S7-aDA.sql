create TYPE         "GridFileType178_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Grids" "Grids179_T")NOT FINAL INSTANTIABLE
/

