create TYPE SDO_MBR
                                                                      
AS OBJECT (
	LOWER_LEFT MDSYS.SDO_VPOINT_TYPE,
	UPPER_RIGHT MDSYS.SDO_VPOINT_TYPE)
/

