create TYPE       SDO_TRANSIENT_RULE
     AS OBJECT (
       SOURCE_SRID NUMBER,
       TARGET_SRID NUMBER,
       TFM         NUMBER)
/

