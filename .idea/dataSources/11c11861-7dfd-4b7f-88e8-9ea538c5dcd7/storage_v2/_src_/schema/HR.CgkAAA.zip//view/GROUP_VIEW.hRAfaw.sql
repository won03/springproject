create view GROUP_VIEW as
SELECT distinct g2.group_id, g2.group_name, g2.group_owner, a.acct_name, a.acct_team_name
FROM account_group_junction g1, groups g2, accounts a
where g2.group_id = g1.group_id 
and g2.group_owner = a.acct_id
/

