create view CART_VIEW as
select  c.p_idx, c.c_idx, c.c_cnt, c.m_idx, c.c_cnt * p.p_saleprice amount,
            p.p_price, p.p_saleprice, p.p_name, p.p_num
    from cart c, product p
    where c.p_idx = p.idx
/

